<?php
use App\Core\Csrf;
use App\Core\Plugin;
use App\Core\PluginHelper;
use App\Core\Request;
use App\Core\Sanitizer;
use App\Core\Session;
use XHiddenProjects\PHPDB\PHPDB;
use XHiddenProjects\PHPDB\PHPDBUtils;
use XHiddenProjects\PHPDB\PHPDBSecurity;
use XHiddenProjects\PHPDB\PHPDBException;
$config = App\Core\Config::getInstance();
date_default_timezone_set($config->get('timezone'));
include_once 'phpdb.php';
!\defined('PHPDB_DIR') ? define('PHPDB_DIR',dirname(__DIR__)) : '';
!\defined('PHPDB_DATABASES') ? define('PHPDB_DATABASES',dirname(__DIR__).DIRECTORY_SEPARATOR.'databases') : '';
!\defined('PHPDB_CREDENTIALS') ? define('PHPDB_CREDENTIALS',dirname(__DIR__).DIRECTORY_SEPARATOR.'phpdb.json') : '';
# Secure and create database account
PHPDBSecurity::secureDatabase(PHPDB_DIR, PHPDBSecurity::EX_LOCK);
if(!file_exists(PHPDB_CREDENTIALS)){
    PHPDBSecurity::createAccount(
        key: 'admin', # Account key
        username: 'localhost', # Username
        password: 'root', # Password
        role: 'admin', # Role
        databases: ['*'], # Databases the user can access, ['*'] = all databases
        can_view: true, # Can view the database
        can_write: true, # Can write the database
        can_create: true, # Can create the database
        can_delete: true, # Can delete the database
        credPath: PHPDB_CREDENTIALS # Credentials path (optional)
    );
}
try{
$request = new Request();
$db = new PHPDB(PHPDB_CREDENTIALS);
$db->Authorize('localhost','root');
if(!file_exists(PHPDB_DATABASES.'/fb_polls.phpdb')) $db->createDatabase('fb_polls',PHPDB_DATABASES);
$db->open('fb_polls');
if(!$db->tableExists('polls')){
    $db->createTable('polls', [
        'id'      => 'INT NOT NULL AUTO_INCREMENT UNIQUE',
        'poll_author'  => 'VARCHAR(255) NOT NULL',
        'poll_id' => 'VARCHAR(64) NOT NULL UNIQUE',
        'poll_title'=>'VARCHAR(150) NOT NULL',
        'poll_description'=>'VARCHAR(200) NULL',
        'poll_options' => 'TEXT NOT NULL',
        'poll_can_expire'=>'BOOL NOT NULL',
        'poll_expire'  => 'DATETIME NULL',
        'poll_status'  => 'ENUM("opened","closed") NOT NULL',
    ]);
}
$ct = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]));
if (empty($_POST) && $ct === 'application/json') {
    $json = json_decode(file_get_contents('php://input'), true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($json)) {
        $_POST = $json;
    }
}

if(isset($_POST['token'])) {
    $translations = PluginHelper::getTranslations('polls');
    $token       = $_POST['token'];
    $pollTitle   = Sanitizer::sanitizeText($_POST['poll_title'] ?? '');
    $pollDesc    = Sanitizer::sanitizeText($_POST['poll_desc'] ?? '');
    $pollId      = Sanitizer::sanitizeText($_POST['poll_id'] ?? '');
    $pollOptions = $_POST['poll_options'] ?? '';
    $pollOptions = Sanitizer::sanitizeText($pollOptions);
    $canExpire = Sanitizer::sanitizeBool($_POST['can_expire']);
    $expire      = $_POST['poll_expire'] ?? '';
    $status      = Sanitizer::sanitizeText($_POST['poll_status'] ?? '');
    if (Csrf::validate($token)) {
        if($pollTitle===''||$pollId===''||($pollOptions===''||count(explode(',',$pollOptions))<2)||$status===''){
            $GLOBALS['results'] = json_encode(['error' => $translations['poll_missing_information'] ?? 'Make sure you fill out all the required inputs'], JSON_UNESCAPED_SLASHES);
        }else{
            if($db->fetch('polls',"WHERE poll_id='$pollId'")){
                $db->update('polls',[
                    'poll_description'=>$pollDesc,
                    'poll_options'=>$pollOptions,
                    'poll_expire'=>$expire,
                    'poll_can_expire'=>$canExpire,
                    'poll_status'=>strtolower($status)
                ],"WHERE poll_id='$pollId'");
                $GLOBALS['results'] = json_encode(['success' => $translations['poll_successfully_updated']??'Poll successfully updated'], JSON_UNESCAPED_SLASHES);
            }else{
                $db->insert('polls',[
                    'poll_author'=>Session::get('username'),
                    'poll_id'=>$pollId,
                    'poll_title'=>$pollTitle,
                    'poll_description'=>$pollDesc,
                    'poll_options'=>$pollOptions,
                    'poll_expire'=>$expire,
                    'poll_can_expire'=>$canExpire,
                    'poll_status'=>strtolower($status)
                ]);
                $columns = [];
                foreach(explode(',',$pollOptions) as $options){
                    $cname = preg_replace('/[.\/\\!@#$%^&*()-=+|\'"<>,?]/','',preg_replace('/ /','_',strtolower($options)));
                    $columns[$cname] = "TEXT NULL";
                }
                if(!$db->tableExists($pollId)) 
                    $db->createTable($pollId,[
                    'id'=>'INT AUTO_INCREMENT',
                    ...$columns
                ]);
                $GLOBALS['results'] = json_encode(['success' => $translations['poll_successfully_created']??'Poll successfully created'], JSON_UNESCAPED_SLASHES);
            }
        }

        
    } else
        $GLOBALS['results'] = json_encode(['error' => $translations['invalid_csrf_token'] ?? 'Invalid token'], JSON_UNESCAPED_SLASHES);
}

$GLOBALS['users_polls'] = $db->fetchAll('polls',"WHERE poll_author='".Session::get('username')."'");
if(isset($_GET['poll_id']))
    $GLOBALS['results'] = json_encode(['poll_data'=>$db->fetch('polls','WHERE poll_id="'.$_GET['poll_id'].'"')]);
if(isset($_POST['vote_action'])&&$_POST['vote_action']==='clear'){
   $tbl = Sanitizer::sanitizeText($_POST['poll_id']);
   if($db->tableExists($tbl)){
     $GLOBALS['results'] = json_encode(['poll_data'=>'']);
   }
}
if(isset($_POST['vote_action'])&&$_POST['vote_action']==='vote'){
   $tbl = Sanitizer::sanitizeText($_POST['poll_id']);
   $selected = Sanitizer::sanitizeArray($_POST['selected_options']);
   if($db->tableExists($tbl)){
        $ip = $request->getIp();
        $pluginData = Plugin::getData('polls');
        $cname = Sanitizer::sanitizeArray($selected, fn($i): array|string|null=>preg_replace('/[.\/\\!@#$%^&*()-=+|\'"<>,?]/','',preg_replace('/ /','_',strtolower($i))));
        $db->insert($tbl,[
            ...array_combine($cname, array_fill(0, count($cname), $ip))
        ]);
        $GLOBALS['results'] = json_encode(['poll_data'=>array_combine($cname, array_fill(0, count($cname), $ip))]);
   }
}
if(isset($_POST['vote_action'])&&$_POST['vote_action']==='check'){
    $options = Sanitizer::sanitizeArray($_POST['poll_options'],fn($i)=>preg_replace('/[.\/\\!@#$%^&*()-=+|\'"<>,?]/','',preg_replace('/ /','_',strtolower($i))));
    $has_voted = false;
    $id = Sanitizer::sanitizeText($_POST['poll_id']);
    foreach($options as $opt){
        $ip = $request->getIp();
        $row = $db->fetch($id, "WHERE $opt='$ip'");
        $has_voted = isset($row[$opt]) ? (is_string($row[$opt]) ? $row[$opt]===$ip : in_array($ip, $row[$opt])) : false;
        if($has_voted) break;
    }
    $GLOBALS['results'] = json_encode(['has_voted'=>$has_voted]);
}
if(isset($_POST['vote_action'])&&$_POST['vote_action']==='results'){
    $id = Sanitizer::sanitizeText($_POST['poll_id']);
    $GLOBALS['results'] = json_encode(['results'=>$db->fetchAll($id)]);
}
$db->close('fb_polls');
}catch (PHPDBException $e) {
    # Nothing
} catch (Throwable $e) {
    # Nothing
}
