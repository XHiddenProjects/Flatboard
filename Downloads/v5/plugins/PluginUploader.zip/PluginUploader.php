<?php
namespace App\Plugins\PluginUploader;
class PluginUploader{
    public function boot(): void{
        # nothing
    }
}