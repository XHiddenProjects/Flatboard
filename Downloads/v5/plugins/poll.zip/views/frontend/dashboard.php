<?php 
use App\Core\Csrf;
use App\Helpers\UrlHelper;
global $translations, $users_polls;
$translations = $translations??[];
$config = App\Core\Config::getInstance();
date_default_timezone_set($config->get('timezone'));
?>
<label class="form-label" for="poll-list"><?=$translations['edit_poll']??'Edit Poll'?> <span class="loading-poll-spinner"></span></label>
<select class="form-select" id="poll-list">
    <option value=""><?=$translations['poll_selection_default']??'Create new poll'?></option>
    <?php
    foreach($users_polls as $polls){
        echo "<option value='{$polls['poll_id']}'>{$polls['poll_title']}</option>";
    }?>
</select>
<hr class="border border-2 border-dark rounded"/>
<form method="post" action="/<?=UrlHelper::getBaseUrl()?>/polls/update" class="pollManagerForm" enctype="multipart/form-data">
    <input type="hidden" name="token" value="<?=Csrf::get();?>"/>
    <div class="row">
        <div class="col">
            <label class="form-label" for="poll_title"><?=$translations['poll_title']??'Poll Title';?></label>
            <input type="text" class="form-control" id="poll_title" name="poll_title">
        </div>
        <div class="col">
            <label class="form-label" for="poll_desc"><?=$translations['poll_desc']??'Poll Description';?></label>
            <input type="text" class="form-control" id="poll_desc" name="poll_desc">
        </div>
        <div class="col">
            <label class="form-label" for="poll_id"><?=$translations['poll_id']??'Poll ID';?></label>
            <input type="text" class="form-control disabled" readonly id="poll_id" name="poll_id">
        </div>
    </div>
    <div class="row">
        <label for="poll_options" class="form-label"><?=$translations['poll_options']??'Poll Options';?></label>
    </div>
    <div class="row poll-option-list-row">
        <input type="hidden" id="poll_options" name="poll_options" value=""/>
        <div class="poll_option_list">
            <div class="input-group poll-option-item mt-1 has-validation">
                <input type="text" placeholder="<?=$translations['poll_option_placeholder']??'Add Option'?>" class="form-control" id="poll_option_0">
            </div>
            <div class="input-group poll-option-item mt-1 has-validation">
                <input type="text" placeholder="<?=$translations['poll_option_placeholder']??'Add Option'?>" class="form-control" id="poll_option_1">
            </div>
        </div>
        <div class="poll-add-option"><i class="fa fa-plus-circle"></i> <?=$translations['add_poll_option']??'Add Option'?></div>
    </div>
    <div class="row">
        <div class="col">
            <label for="poll_expire" class="form-label"><?=$translations['poll_expire']??'Expire'?></label>
            <span class="text-muted poll-expire-desc"><?=$translations['poll_expire_desc']??'(Leave it empty if you want unlimited)'?></span>
            <input class="form-control" min="<?=date('Y-m-d\T00:00',strtotime('+1 hour'))?>" type="datetime-local" name="poll_expire" id="poll_expire"/>
        </div>
        <div class="col">
            <label for="poll_status" class="form-label"><?=$translations['poll_status']??'Poll Status'?></label>
            <select class="form-select" name="poll_status" id="poll_status">
                <option value="opened"><?=$translations['poll_status_open']??'Opened'?></option>
                <option value="closed"><?=$translations['poll_status_closed']??'Closed'?></option>
            </select>
        </div>
    </div>
    <button class="btn btn-primary mt-1 ms-auto d-block" type="submit" name="poll_save"><?=$translations['poll_save']??'Create/Update'?></button>
    </div>
</form>