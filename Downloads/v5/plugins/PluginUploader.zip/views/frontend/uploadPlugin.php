<?php
/**
 * PluginUploader - Endpoint d'upload de plugins
 * Nécessite l'authentification admin
 */

// Charger le bootstrap de Flatboard
require_once dirname(__DIR__, 4) . '/app/Core/Autoloader.php';
define('BASE_PATH',dirname(__DIR__,4));
Autoloader::register(BASE_PATH);
use App\Services\UploadService;
use App\Core\Csrf;
use App\Core\PluginHelper;
use App\Core\Session;

// Vérifier l'authentification admin
$userId = Session::get('user_id');
if (!$userId || !\App\Helpers\GroupHelper::isAdmin($userId)) {
    http_response_code(403);
    echo json_encode(['error' => 'Accès refusé. Authentification admin requise.']);
    exit;
}

$translations = PluginHelper::getTranslations('plugin-uploader');

function extractZip($zipFilePath, $extractToPath): bool {
    $zip = new ZipArchive();
    if ($zip->open($zipFilePath) === TRUE) {
        $zip->extractTo($extractToPath);
        $zip->close();
        return true;
    } else {
        return false;
    }
}

function flattenFilesArray($files): array {
    $flattened = [];
    if (is_array($files['name'])) {
        foreach ($files['name'] as $index => $name) {
            $flattened[] = [
                'name' => $name,
                'type' => pathinfo($files['name'][$index], PATHINFO_EXTENSION),
                'tmp_name' => $files['tmp_name'][$index],
                'error' => $files['error'][$index],
                'size' => $files['size'][$index],
            ];
        }
    } else {
        // Single file upload
        $flattened[] = $files;
    }
    return $flattened;
}

// Initialize variables
$hasSuccess = false;
$hasError = false;
$errorMessages = [];
$successMessage = '';

if (Csrf::validate($_POST['csrfToken'])) {
    $maxSizeBytes = ini_parse_quantity(ini_get('upload_max_filesize'));
    $filesArray = flattenFilesArray($_FILES['pluginUpload']);

    foreach ($filesArray as $file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $hasError = true;
            $errorMessages[] = $translations['upload_error'] ?? 'Upload error for file: ' . htmlspecialchars($file['name']);
            continue;
        }

        if (UploadService::validate($file, ['zip'], $maxSizeBytes)) {
            $zipFilePath = $file['tmp_name'];
            $name = $file['name'];
            $extractToPath = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . preg_replace('/\..*/', '', $name);

            if (extractZip($zipFilePath, $extractToPath)) {
                $hasSuccess = true;
                $successMessage = $translations['uploaded_completed'] ?? 'Extraction completed';
            } else {
                $hasError = true;
                $errorMessages[] = $translations['failed_to_extract'] ?? 'Failed to extract ZIP file';
            }
        } else {
            $hasError = true;
            $errorMessages[] = $translations['invalid_fileType'] ?? 'Invalid file type';
        }
    }
} else {
    $hasError = true;
    $errorMessages[] = $translations['invalid_csrf'] ?? 'Invalid CSRF';
}

// Prepare final response
if ($hasSuccess) {
    // If at least one success, prioritize success message
    $response = ['success' => $successMessage];
} elseif ($hasError) {
    // Else, if errors occurred, list all errors
    $response = ['error' => implode("\n", $errorMessages)];
} else {
    // No files processed, fallback message
    $response = ['error' => $translations['no_files_processed'] ?? 'No files processed'];
}

// Output final JSON
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);