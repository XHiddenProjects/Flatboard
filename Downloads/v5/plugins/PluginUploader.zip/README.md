# PluginUploader
PluginUploader is a simple, hassle-free tool designed to make uploading plugins to Flatboard effortless. Streamline your plugin management process with this easy-to-use uploader.

## Features
* Easy drag-and-drop interface
* Supports multiple plugin uploads at once
* Validates plugin files before upload
* Seamless integration with Flatboard
* No technical hassle required
* Only support **(ZIP files)**

## Installation
* Download the PluginUploader script.
* Upload the script to your Flatboard plugin directory.
* Ensure proper permissions are set for the uploader.
* Access the uploader through your Flatboard admin panel.

## Usage
* Log in to your Flatboard admin panel.
* Navigate to the PluginUploader section.
* Drag your plugin files into the upload area or select files manually.
* Click Upload to add plugins directly to your Flatboard installation.
* Refresh your plugins list to see the newly uploaded plugins.

## Releases
* 1.0.0 - Released
* 1.0.1 - Updated where the file will say *"file not found"*

## License
This project is licensed under the GPL-3 License.