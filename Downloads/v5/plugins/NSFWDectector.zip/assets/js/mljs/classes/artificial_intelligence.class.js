
import { SpellChecker } from "../extras/spell_checker.js";

/* =========================================================================================
 * NLP (Naive Bayes-like text classifier with multilingual support)
 * =======================================================================================*/
export const NLP = class {
  constructor() {
    const language = navigator.language.split('-');
    // Multilingual support: store per-language models
    this.languages = new Set();
    this.models = {}; // lang -> model object (documents, answers, vocabulary, tokenCounts, docCount, totalDocs, totalTokensPerIntent, isTrained)
    this.activeLanguage = 'default';
    this.smoothing = 1; // Laplace smoothing
    this.spellChecker = new SpellChecker(language[0], language[1]);
    // create default language model
    this.addLanguage(this.activeLanguage);
  }

  addLanguage(lang) {
    if (!lang) throw new Error('language required');
    if (!this.languages.has(lang)) {
      this.languages.add(lang);
      this.models[lang] = {
        documents: [], // { text, tokens, intent }
        answers: {},   // intent -> [answers]
        vocabulary: new Set(),
        tokenCounts: {}, // intent -> { token: count }
        docCount: {},    // intent -> number
        totalDocs: 0,
        totalTokensPerIntent: {},
        isTrained: false,
      };
    }
    this.activeLanguage = lang;
    return this.models[lang];
  }

  _getModel(lang) {
    // Prefer explicit lang; otherwise navigator language; fallback to activeLanguage; finally 'en'
    const l = (lang ?? navigator.language?.substring(0, 2) ?? this.activeLanguage ?? 'en');
    const m = this.models[l];
    if (!m) throw new Error(`language not found: ${l}`);
    return m;
  }

  tokenize(text) {
    if (!text) return [];
    const tokens = String(text)
      .toLowerCase()
      .split(/\W+/)
      .filter((t) => t.length > 1)
      .map((token) => {
        const corrected = this.spellChecker.spellCheckFromURL(token);
        return corrected === token ? token : corrected.split(' ')[0].toLowerCase();
      });
    return tokens;
  }

  addDocument(text, intent, lang) {
    const tokens = this.tokenize(text);
    const model = this._getModel(lang);
    model.documents.push({ text, tokens, intent });
    model.isTrained = false;
  }

  addAnswer(intent, answer, lang) {
    const model = this._getModel(lang);
    if (!model.answers[intent]) model.answers[intent] = [];
    model.answers[intent].push(answer);
  }

  train(lang) {
    // Train model for a specific language (or active language if not provided)
    const model = this._getModel(lang);
    // Reset counts
    model.vocabulary = new Set();
    model.tokenCounts = {};
    model.docCount = {};
    model.totalTokensPerIntent = {};
    model.totalDocs = model.documents.length;

    for (const doc of model.documents) {
      const intent = doc.intent;
      if (!model.tokenCounts[intent]) model.tokenCounts[intent] = {};
      if (!model.docCount[intent]) model.docCount[intent] = 0;
      if (!model.totalTokensPerIntent[intent]) model.totalTokensPerIntent[intent] = 0;

      model.docCount[intent]++;

      for (const token of doc.tokens) {
        model.vocabulary.add(token);
        model.tokenCounts[intent][token] = (model.tokenCounts[intent][token] || 0) + 1;
        model.totalTokensPerIntent[intent]++;
      }
    }
    model.isTrained = true;
  }

  _scoreForIntent(tokens, intent, lang) {
    // Returns log-probability score for intent
    const model = this._getModel(lang);
    const docCountForIntent = (model.docCount && model.docCount[intent]) || 0;
    if (docCountForIntent === 0) return -Infinity;

    const prior = docCountForIntent / Math.max(1, model.totalDocs || 1);
    let logProb = Math.log(prior);

    const tokenCounts = model.tokenCounts[intent] || {};
    const totalTokens = model.totalTokensPerIntent[intent] || 0;
    const V = Math.max(1, model.vocabulary.size);

    for (const token of tokens) {
      const count = tokenCounts[token] || 0;
      const prob = (count + this.smoothing) / (totalTokens + this.smoothing * V);
      logProb += Math.log(prob);
    }
    return logProb;
  }

  classify(text, lang) {
    // classify in a given language or active language
    const model = this._getModel(lang);
    if (!model.isTrained) this.train(lang);

    const tokens = this.tokenize(text);
    const intents = Object.keys(model.docCount);
    if (intents.length === 0) return { intent: null, score: 0 };

    const scores = {};
    let maxLog = -Infinity;

    for (const intent of intents) {
      const s = this._scoreForIntent(tokens, intent, lang);
      scores[intent] = s;
      if (s > maxLog) maxLog = s;
    }

    // Convert log-scores to normalized probabilities (softmax) for readability
    const expScores = {};
    let sum = 0;
    for (const intent of intents) {
      // subtract maxLog for numerical stability
      const v = Math.exp(scores[intent] - maxLog);
      expScores[intent] = v;
      sum += v;
    }

    const probs = {};
    for (const intent of intents) probs[intent] = expScores[intent] / sum;

    // pick best
    let best = intents[0];
    for (const intent of intents) {
      if (probs[intent] > probs[best]) best = intent;
    }
    return { intent: best, score: probs[best], probabilities: probs };
  }

  process(text, lang) {
    const tokens = this.tokenize(text);
    const classification = this.classify(text, lang);
    const intentName = classification.intent;
    const model = this._getModel(lang);
    const answers = intentName ? (model.answers[intentName] || []) : [];
    return {
      src: text,
      tokens,
      intent: { name: intentName, score: classification.score },
      answers,
      classification: classification.probabilities,
    };
  }

  getAnswers(intent, lang) {
    const model = this._getModel(lang);
    return model.answers[intent] ? Array.from(model.answers[intent]) : [];
  }

  toJSON() {
    // serialize all language models
    const models = {};
    for (const lang of this.languages) {
      const m = this.models[lang];
      models[lang] = {
        documents: m.documents,
        answers: m.answers,
        vocabulary: Array.from(m.vocabulary),
        tokenCounts: m.tokenCounts,
        docCount: m.docCount,
        totalDocs: m.totalDocs,
        totalTokensPerIntent: m.totalTokensPerIntent,
        isTrained: !!m.isTrained,
      };
    }
    return {
      activeLanguage: this.activeLanguage,
      models,
      smoothing: this.smoothing,
    };
  }

  static fromJSON(data) {
    const n = new NLP();
    if (data && data.models) {
      for (const lang of Object.keys(data.models)) {
        n.addLanguage(lang);
        const msrc = data.models[lang];
        const m = n.models[lang];
        m.documents = msrc.documents || [];
        m.answers = msrc.answers || {};
        m.vocabulary = new Set(msrc.vocabulary || []);
        m.tokenCounts = msrc.tokenCounts || {};
        m.docCount = msrc.docCount || {};
        m.totalDocs = msrc.totalDocs || m.documents.length;
        m.totalTokensPerIntent = msrc.totalTokensPerIntent || {};
        m.isTrained = !!msrc.isTrained;
      }
    }
    if (data && data.activeLanguage) n.activeLanguage = data.activeLanguage;
    n.smoothing = typeof data?.smoothing === 'number' ? data.smoothing : 1;
    return n;
  }
};

/* =========================================================================================
 * CNN: Compares images/videos and computes a similarity score.
 * Features:
 *  - Supports Image/Canvas/ImageBitmap, Blob/File/ArrayBuffer, and URL(string) sources.
 *  - Video comparison by sampling frames across duration.
 *  - Computes metrics: MSE, PSNR, SSIM, Histogram Intersection, pHash.
 *  - Returns a weighted aggregate similarity in [0..1] + per-metric details.
 * =======================================================================================*/
export const CNN = class {
  /**
   * @param {Object} [options]
   * @param {number} [options.targetSize=256] - Square target dimension (px) for analysis.
   * @param {'contain'|'cover'} [options.resizeMode='contain'] - Canvas fitting strategy.
   * @param {boolean} [options.grayscale=true] - Convert to grayscale before metrics.
   * @param {Object} [options.weights] - Metric weights; keys: mse, psnr, ssim, hist, phash.
   * @param {number} [options.videoFrameSamples=12] - Number of frames to sample when comparing videos.
   * @param {number} [options.maxPSNR=60] - Upper bound to normalize PSNR (dB) into [0..1].
   */
  constructor(options = {}) {
    this.targetSize = options.targetSize ?? 256;
    this.resizeMode = options.resizeMode ?? 'contain';
    this.grayscale = options.grayscale ?? true;
    this.videoFrameSamples = options.videoFrameSamples ?? 12;
    this.maxPSNR = options.maxPSNR ?? 60;
    this.weights = Object.assign(
      { mse: 1, psnr: 1, ssim: 2, hist: 1, phash: 2 },
      options.weights ?? {}
    );
    // Reusable offscreen canvas
    this._canvas = document.createElement('canvas');
    this._ctx = this._canvas.getContext('2d', { willReadFrequently: true });
  }

  /** Top-level compare function. Detects image vs video and routes accordingly. */
  async compare(a, b) {
    const aKind = await this._detectKind(a);
    const bKind = await this._detectKind(b);

    if (aKind !== bKind) {
      // If kinds differ (e.g., image vs video), try to compare first video frames to the image.
      // Practical fallback rather than hard failing.
      if (aKind === 'video' && bKind === 'image') {
        return this._compareVideoToImage(a, b);
      } else if (aKind === 'image' && bKind === 'video') {
        const res = await this._compareVideoToImage(b, a);
        return res; // swap perspective
      }
      throw new Error('Unsupported: sources are of different kinds and no fallback applied');
    }
    return aKind === 'video'
      ? this._compareVideos(a, b)
      : this._compareImages(a, b);
  }

  /* --------------------------- Loading Helpers --------------------------- */
  async _detectKind(src) {
    const el = await this._materializeSource(src);
    if (el instanceof HTMLVideoElement) return 'video';
    return 'image';
  }

  async _materializeSource(src) {
    // Already an element?
    if (
      (src instanceof HTMLImageElement) ||
      (src instanceof HTMLCanvasElement) ||
      (typeof ImageBitmap !== 'undefined' && src instanceof ImageBitmap)
    ) {
      return src;
    }
    if (src instanceof HTMLVideoElement) return src;

    // Blob/File/ArrayBuffer/URL string
    if (src instanceof Blob) {
      if (src.type.startsWith('video/')) return await this._loadVideoFromBlob(src);
      return await this._loadImageFromBlob(src);
    }
    if (src instanceof ArrayBuffer) {
      const blob = new Blob([src]);
      return await this._materializeSource(blob);
    }
    if (typeof src === 'string') {
      // Heuristic by extension; attempt video by common extensions else image
      const lower = src.toLowerCase();
      if (lower.match(/\.(mp4|webm|ogg|mov)$/)) {
        return await this._loadVideoFromURL(src);
      }
      return await this._loadImageFromURL(src);
    }
    throw new Error('Unsupported source type');
  }

  async _loadImageFromURL(url) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.decoding = 'async';
    img.src = url;
    await img.decode().catch(() => new Promise((res, rej) => {
      img.onload = () => res();
      img.onerror = (e) => rej(e);
    }));
    return img;
  }

  async _loadImageFromBlob(blob) {
    const url = URL.createObjectURL(blob);
    try {
      const img = await this._loadImageFromURL(url);
      return img;
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  async _loadVideoFromURL(url) {
    const video = document.createElement('video');
    video.crossOrigin = 'anonymous';
    video.src = url;
    video.muted = true; // allows autoplay seeking on some browsers
    await this._awaitVideoReady(video);
    return video;
  }

  async _loadVideoFromBlob(blob) {
    const url = URL.createObjectURL(blob);
    try {
      const video = await this._loadVideoFromURL(url);
      return video;
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  _awaitVideoReady(video) {
    return new Promise((resolve, reject) => {
      const onReady = () => { cleanup(); resolve(); };
      const onError = (e) => { cleanup(); reject(e); };
      const cleanup = () => {
        video.removeEventListener('loadeddata', onReady);
        video.removeEventListener('error', onError);
      };
      if (video.readyState >= 2) return resolve();
      video.addEventListener('loadeddata', onReady);
      video.addEventListener('error', onError);
    });
  }

  /* ----------------------------- Canvas/Resize --------------------------- */
  _drawToCanvas(source) {
    // Determine intrinsic size
    let sw, sh;
    if ((source instanceof HTMLImageElement) || (source instanceof HTMLVideoElement)) {
      sw = source.videoWidth || source.naturalWidth || source.width;
      sh = source.videoHeight || source.naturalHeight || source.height;
    } else if (source instanceof HTMLCanvasElement) {
      sw = source.width; sh = source.height;
    } else if (typeof ImageBitmap !== 'undefined' && source instanceof ImageBitmap) {
      sw = source.width; sh = source.height;
    } else {
      throw new Error('Unsupported source for canvas draw');
    }

    // Target canvas size
    const tw = this.targetSize, th = this.targetSize;
    this._canvas.width = tw;
    this._canvas.height = th;

    // Compute fit rect
    const srcAspect = sw / sh;
    const dstAspect = tw / th;
    let dw, dh;
    if (this.resizeMode === 'cover'
        ? (srcAspect < dstAspect)
        : (srcAspect > dstAspect)) {
      // match width
      dw = tw;
      dh = tw / srcAspect;
    } else {
      // match height
      dh = th;
      dw = th * srcAspect;
    }
    const dx = (tw - dw) / 2;
    const dy = (th - dh) / 2;

    // Clear & draw
    this._ctx.clearRect(0, 0, tw, th);
    this._ctx.drawImage(source, dx, dy, dw, dh);
    return this._ctx.getImageData(0, 0, tw, th);
  }

  _toGrayscale(imageData) {
    const { data, width, height } = imageData;
    const gray = new Float32Array(width * height);
    for (let i = 0, p = 0; i < data.length; i += 4, p++) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      // Rec. 709 luminance
      gray[p] = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }
    return { gray, width, height };
  }

  // --- Helpers to support optional grayscale ---
  _ensureGrayOrColor(imageData) {
    // If grayscale option is on, produce gray; else return color view + on-demand gray builder
    if (this.grayscale) {
      const g = this._toGrayscale(imageData);
      return { mode: 'gray', gray: g.gray, width: g.width, height: g.height, imageData };
    }
    // Provide a facade for color access and a lazy luminance builder when needed
    const { data, width, height } = imageData;
    const getLuminance = () => {
      const gray = new Float32Array(width * height);
      for (let i = 0, p = 0; i < data.length; i += 4, p++) {
        const r = data[i], g = data[i + 1], b = data[i + 2];
        gray[p] = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      }
      return gray;
    };
    return { mode: 'color', imageData, width, height, getLuminance };
  }

  /* ------------------------------- Metrics ------------------------------- */
  _mse(grayA, grayB) {
    let mse = 0;
    for (let i = 0; i < grayA.length; i++) {
      const d = grayA[i] - grayB[i];
      mse += d * d;
    }
    mse /= grayA.length;
    // Normalize to [0..1] by max possible (255^2)
    const nmse = mse / (255 * 255);
    return { mse, nmse, similarity: Math.max(0, 1 - nmse) };
  }

  // --- Color-aware MSE over RGB channels (average of per-channel MSEs) ---
  _mseColor(imageDataA, imageDataB) {
    const a = imageDataA.data, b = imageDataB.data;
    let mseR = 0, mseG = 0, mseB = 0, pixels = a.length / 4;
    for (let i = 0; i < a.length; i += 4) {
      const dR = a[i]   - b[i];
      const dG = a[i+1] - b[i+1];
      const dB = a[i+2] - b[i+2];
      mseR += dR * dR;
      mseG += dG * dG;
      mseB += dB * dB;
    }
    mseR /= pixels; mseG /= pixels; mseB /= pixels;
    const mse = (mseR + mseG + mseB) / 3;
    const nmse = mse / (255 * 255);
    return { mse, nmse, similarity: Math.max(0, 1 - nmse) };
  }

  _psnr(mse) {
    if (mse === 0) return { psnr: this.maxPSNR, similarity: 1 };
    const psnr = 10 * Math.log10((255 * 255) / mse);
    const similarity = Math.max(0, Math.min(1, psnr / this.maxPSNR));
    return { psnr, similarity };
  }

  _stats(gray) {
    let mean = 0;
    for (let i = 0; i < gray.length; i++) mean += gray[i];
    mean /= gray.length;

    let varSum = 0;
    for (let i = 0; i < gray.length; i++) {
      const d = gray[i] - mean;
      varSum += d * d;
    }
    const variance = varSum / gray.length;
    return { mean, variance };
  }

  _cov(grayA, meanA, grayB, meanB) {
    let cov = 0;
    for (let i = 0; i < grayA.length; i++) {
      cov += (grayA[i] - meanA) * (grayB[i] - meanB);
    }
    return cov / grayA.length;
  }

  _ssim(grayA, grayB) {
    // Global SSIM approximation
    const { mean: muX, variance: sigmaX2 } = this._stats(grayA);
    const { mean: muY, variance: sigmaY2 } = this._stats(grayB);
    const sigmaXY = this._cov(grayA, muX, grayB, muY);
    const L = 255;
    const k1 = 0.01, k2 = 0.03;
    const C1 = (k1 * L) ** 2;
    const C2 = (k2 * L) ** 2;
    const numerator = (2 * muX * muY + C1) * (2 * sigmaXY + C2);
    const denominator = (muX*muX + muY*muY + C1) * (sigmaX2 + sigmaY2 + C2);
    let ssim = numerator / denominator;
    // Bound to [0..1]
    ssim = Math.max(0, Math.min(1, ssim));
    return { ssim, similarity: ssim };
  }

  // --- Color-aware SSIM: compute per-channel SSIM and average ---
  _statsColorChannel(imageData, channelIndex) {
    const d = imageData.data;
    let mean = 0;
    const pixels = d.length / 4;
    for (let i = channelIndex; i < d.length; i += 4) mean += d[i];
    mean /= pixels;

    let varSum = 0;
    for (let i = channelIndex; i < d.length; i += 4) {
      const diff = d[i] - mean;
      varSum += diff * diff;
    }
    const variance = varSum / pixels;
    return { mean, variance };
  }

  _covColorChannel(imgA, meanA, imgB, meanB, channelIndex) {
    const a = imgA.data, b = imgB.data;
    let cov = 0, pixels = a.length / 4;
    for (let i = channelIndex; i < a.length; i += 4) {
      cov += (a[i] - meanA) * (b[i] - meanB);
    }
    return cov / pixels;
  }

  _ssimColor(imageDataA, imageDataB) {
    const L = 255, k1 = 0.01, k2 = 0.03;
    const C1 = (k1 * L) ** 2;
    const C2 = (k2 * L) ** 2;

    const ssimForChannel = (ch) => {
      const { mean: muX, variance: sigmaX2 } = this._statsColorChannel(imageDataA, ch);
      const { mean: muY, variance: sigmaY2 } = this._statsColorChannel(imageDataB, ch);
      const sigmaXY = this._covColorChannel(imageDataA, muX, imageDataB, muY, ch);
      const numerator = (2 * muX * muY + C1) * (2 * sigmaXY + C2);
      const denominator = (muX*muX + muY*muY + C1) * (sigmaX2 + sigmaY2 + C2);
      const v = numerator / denominator;
      return Math.max(0, Math.min(1, v));
    };

    const sR = ssimForChannel(0);
    const sG = ssimForChannel(1);
    const sB = ssimForChannel(2);
    const ssim = (sR + sG + sB) / 3;
    return { ssim, similarity: ssim };
  }

  _histIntersection(imageDataA, imageDataB, bins = 32) {
    const histA = new Float32Array(bins);
    const histB = new Float32Array(bins);
    const push = (data, hist) => {
      for (let i = 0; i < data.length; i += 4) {
        // grayscale bin for simplicity (fast, robust)
        const g = 0.2126*data[i] + 0.7152*data[i+1] + 0.0722*data[i+2];
        const idx = Math.min(bins - 1, Math.floor(g / (256 / bins)));
        hist[idx]++;
      }
    };
    push(imageDataA.data, histA);
    push(imageDataB.data, histB);

    let intersection = 0, sumA = 0, sumB = 0;
    for (let i = 0; i < bins; i++) {
      intersection += Math.min(histA[i], histB[i]);
      sumA += histA[i];
      sumB += histB[i];
    }
    const denom = Math.max(sumA, sumB, 1);
    const similarity = intersection / denom; // [0..1]
    return { similarity, intersection, denom };
  }

  // Accept either a precomputed gray buffer OR an ImageData to derive luminance
  _pHash(grayOrImage, width, height) {
    let gray, w = width, h = height;

    if (grayOrImage instanceof Float32Array) {
      gray = grayOrImage;
    } else {
      const imageData = grayOrImage; // ImageData
      const { data } = imageData;
      gray = new Float32Array(w * h);
      for (let i = 0, p = 0; i < data.length; i += 4, p++) {
        gray[p] = 0.2126*data[i] + 0.7152*data[i+1] + 0.0722*data[i+2];
      }
    }

    // Resize to 32x32 then DCT, then 8x8 top-left
    const N = 32, K = 8;

    // Put grayscale into an ImageData so we can draw/scale via canvas
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = N; tempCanvas.height = N;
    const ctx = tempCanvas.getContext('2d', { willReadFrequently: true });

    const imgData = ctx.createImageData(w, h);
    for (let i = 0, p = 0; i < imgData.data.length; i += 4, p++) {
      const g = Math.max(0, Math.min(255, gray[p]));
      imgData.data[i] = g; imgData.data[i+1] = g; imgData.data[i+2] = g; imgData.data[i+3] = 255;
    }
    const srcCanvas = document.createElement('canvas');
    srcCanvas.width = w; srcCanvas.height = h;
    const sctx = srcCanvas.getContext('2d', { willReadFrequently: true });
    sctx.putImageData(imgData, 0, 0);
    ctx.drawImage(srcCanvas, 0, 0, N, N);
    const resized = ctx.getImageData(0, 0, N, N);

    // Build grayscale array for DCT input
    const block = new Float32Array(N * N);
    for (let i = 0, p = 0; i < resized.data.length; i += 4, p++) {
      block[p] = resized.data[i]; // already grayscale
    }
    const dct = this._dct2(block, N);

    // Compute mean of top-left 8x8 excluding DC (0,0)
    let sum = 0, count = 0;
    for (let u = 0; u < K; u++) {
      for (let v = 0; v < K; v++) {
        if (u === 0 && v === 0) continue;
        sum += dct[u*N + v]; count++;
      }
    }
    const mean = sum / Math.max(1, count);

    // Build 64-bit hash (as array of 64 bits)
    const bits = [];
    for (let u = 0; u < K; u++) {
      for (let v = 0; v < K; v++) {
        if (u === 0 && v === 0) continue;
        bits.push(dct[u*N + v] > mean ? 1 : 0);
      }
    }
    // pad with DC comparison to mean for 64th bit
    bits.push(dct[0] > mean ? 1 : 0);
    return bits;
  }

  _dct2(block, N) {
    // Simple 2D DCT (naive, O(N^4) but N is small for pHash)
    const out = new Float32Array(N * N);
    const c = (x) => (x === 0 ? Math.sqrt(1/N) : Math.sqrt(2/N));
    for (let u = 0; u < N; u++) {
      for (let v = 0; v < N; v++) {
        let sum = 0;
        for (let x = 0; x < N; x++) {
          for (let y = 0; y < N; y++) {
            sum += block[x*N + y] *
              Math.cos(((2*x + 1) * u * Math.PI) / (2 * N)) *
              Math.cos(((2*y + 1) * v * Math.PI) / (2 * N));
          }
        }
        out[u*N + v] = c(u) * c(v) * sum;
      }
    }
    return out;
  }

  _hamming(aBits, bBits) {
    const n = Math.min(aBits.length, bBits.length);
    let dist = 0;
    for (let i = 0; i < n; i++) if (aBits[i] !== bBits[i]) dist++;
    dist += Math.abs(aBits.length - bBits.length); // if lengths differ
    return dist;
  }

  /* --------------------------- Image Comparison -------------------------- */
  async _compareImages(a, b) {
    const srcA = await this._materializeSource(a);
    const srcB = await this._materializeSource(b);
    const dataA = this._drawToCanvas(srcA);
    const dataB = this._drawToCanvas(srcB);

    const A = this._ensureGrayOrColor(dataA);
    const B = this._ensureGrayOrColor(dataB);
    // MSE + PSNR
    const mseRes = (A.mode === 'gray')
      ? this._mse(A.gray, B.gray)
      : this._mseColor(A.imageData, B.imageData);

    const psnrRes = this._psnr(mseRes.mse);

    // SSIM
    const ssimRes = (A.mode === 'gray')
      ? this._ssim(A.gray, B.gray)
      : this._ssimColor(A.imageData, B.imageData);

    // Histogram Intersection (uses original ImageData)
    const histRes = this._histIntersection(dataA, dataB);

    // pHash: luminance-based (use provided gray if available; else derive from ImageData)
    const phA = (A.mode === 'gray')
      ? this._pHash(A.gray, dataA.width, dataA.height)
      : this._pHash(A.imageData, dataA.width, dataA.height);

    const phB = (B.mode === 'gray')
      ? this._pHash(B.gray, dataB.width, dataB.height)
      : this._pHash(B.imageData, dataB.width, dataB.height);

    const hamming = this._hamming(phA, phB);
    const phashSim = Math.max(0, 1 - (hamming / 64));

    const metrics = {
      mse: mseRes.similarity,
      psnr: psnrRes.similarity,
      ssim: ssimRes.similarity,
      hist: histRes.similarity,
      phash: phashSim
    };

    const similarity = this._weightedAggregate(metrics);
    return { similarity, metrics, kind: 'image' };
  }

  _weightedAggregate(metrics) {
    let wsum = 0, acc = 0;
    for (const key of Object.keys(this.weights)) {
      const w = this.weights[key] ?? 0;
      if (w <= 0) continue;
      const v = metrics[key] ?? 0;
      acc += w * v;
      wsum += w;
    }
    return wsum > 0 ? acc / wsum : 0;
  }

  /* --------------------------- Video Comparison -------------------------- */
  async _compareVideos(a, b) {
    const videoA = await this._materializeSource(a);
    const videoB = await this._materializeSource(b);
    const framesA = await this._sampleVideoFrames(videoA, this.videoFrameSamples);
    const framesB = await this._sampleVideoFrames(videoB, this.videoFrameSamples);
    const n = Math.min(framesA.length, framesB.length);
    let aggSimilarity = 0;
    const details = [];
    for (let i = 0; i < n; i++) {
      const { similarity, metrics } = await this._compareImages(framesA[i], framesB[i]);
      aggSimilarity += similarity;
      details.push(metrics);
    }
    const similarity = n > 0 ? aggSimilarity / n : 0;
    return { similarity, metricsPerFrame: details, kind: 'video' };
  }

  async _sampleVideoFrames(video, samples) {
    await this._awaitVideoReady(video);
    const duration = video.duration || 0;
    if (!duration || !isFinite(duration)) {
      // Fallback: single current frame
      return [video];
    }

    const timestamps = [];
    // Sample from 10% to 90% to avoid blank first/last frames
    const start = duration * 0.1, end = duration * 0.9;
    const step = (end - start) / Math.max(1, (samples - 1));
    for (let i = 0; i < samples; i++) timestamps.push(start + i * step);

    const frames = [];
    for (const t of timestamps) {
      await this._seekVideo(video, t);
      const frameData = this._drawToCanvas(video);
      // Convert ImageData back into a pseudo-image source for reuse
      const frameCanvas = document.createElement('canvas');
      frameCanvas.width = frameData.width;
      frameCanvas.height = frameData.height;
      const ctx = frameCanvas.getContext('2d', { willReadFrequently: true });
      ctx.putImageData(frameData, 0, 0);
      frames.push(frameCanvas);
    }
    return frames;
  }

  _seekVideo(video, time) {
    return new Promise((resolve, reject) => {
      const onSeeked = () => { cleanup(); resolve(); };
      const onError = (e) => { cleanup(); reject(e); };
      const cleanup = () => {
        video.removeEventListener('seeked', onSeeked);
        video.removeEventListener('error', onError);
      };
      video.addEventListener('seeked', onSeeked);
      video.addEventListener('error', onError);
      video.currentTime = Math.min(Math.max(0, time), video.duration || 0);
    });
  }

  /* ------------------------- Video-to-Image Fallback --------------------- */
  async _compareVideoToImage(videoSrc, imageSrc) {
    const video = await this._materializeSource(videoSrc);
    const image = await this._materializeSource(imageSrc);
    const frames = await this._sampleVideoFrames(video, this.videoFrameSamples);
    let best = 0;
    let bestMetrics = null;
    for (const f of frames) {
      const { similarity, metrics } = await this._compareImages(f, image);
      if (similarity > best) {
        best = similarity;
        bestMetrics = metrics;
      }
    }
    return { similarity: best, metrics: bestMetrics || {}, kind: 'video-image' };
  }
};





/* ============================================================
 * VoiceMimic v6 — AlwaysAudible + Actual Words
 * - Always produces audible sound:
 *    • Ensures AudioContext is running (resume watchdog)
 *    • Per-phoneme envelope floor (never ramps to total silence)
 *    • Resilient source selection (mic PSOLA -> glottal oscillator)
 *    • Normalized mic residual grain to safe level
 * - Actual words:
 *    • Improved G2P (lexicon first, rules with syllables + stress)
 *    • Schwa insertion across consonant clusters
 * - Public API unchanged: startRecording(), stopRecording(), speak(text, opts),
 *   calibrate(), exportProfile(), importProfile()
 * - No external APIs — pure WebAudio
 * ========================================================== */

export const VoiceMimic = class {
  constructor(options = {}) {
    this.sampleRate = options.sampleRate ?? 44100;
    this.maxRecordSec = options.maxRecordSec ?? 15;
    this.debug = !!options.debug;

    // Runtime
    this.audioCtx = null;
    this.mediaStream = null;
    this.mediaRecorder = null;
    this._chunks = [];
    this.sampleBuffer = null;
    this.sampleBlob = null;
    this.masterGain = null;

    // Voice profile (compatible with previous versions)
    this.voiceProfile = {
      f0Mean: 140,
      f0Std: 20,
      spectralTilt: -6,
      formants: [700, 1200, 2600],
      speakingRate: 12
    };

    // Timbre coloration (LPC/IIR or PEQ)
    this.lpcOrder = 10;
    this.iirFeedforward = [1];
    this.iirFeedback  = [1];
    this.timbreMode   = 'none';
    this.timbreReady  = false;
    this.peqSettings  = [];

    // Mic excitation (PSOLA)
    this.excitationReady = false;
    this.excitationGrainData = null; // Float32Array
    this.excitationGrainF0   = null; // Hz
    this.excitationGrainSR   = null; // SR
    this._excitationBufferCache = null;

    // Safety: minimum envelope gain so filters/compressor never push total silence
    this._envFloor = 0.02; // ≈ -34 dB; quiet but audible

    // Small lexicon (extend as needed)
    this.lexicon = new Map([
      ['hello','HH EH L OW'], ['hi','HH AY'], ['hey','HH EY'],
      ['copilot','K OW P AY L AA T'],
      ['i','AY'], ['you','Y UW'], ['we','W IY'], ['they','DH EY'],
      ['the','DH AH'], ['this','DH IH S'], ['is','IH Z'], ['are','AA R'],
      ['test','T EH S T'], ['voice','V OY S'], ['mimic','M IH M IH K'],
      ['my','M AY'], ['your','Y AO R'], ['name','N EY M'], ['today','T AH D EY'],
      ['thanks','TH AE NG K S'], ['please','P L IY Z']
    ]);

    // Vowels set (ARPABET)
    this._VOWELS = new Set(['AA','AE','AH','AO','AW','AY','EH','ER','EY','IH','IY','OW','OY','UH','UW']);
  }

  /* ======================== Recording ======================== */
  async startRecording() {
    await this.#ensureAudioOutput(); // make sure context is alive
    this._chunks = [];
    this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.mediaRecorder = new MediaRecorder(this.mediaStream, { mimeType: 'audio/webm' });

    const stopTimeout = setTimeout(() => {
      if (this.mediaRecorder && this.mediaRecorder.state === 'recording') this.mediaRecorder.stop();
    }, this.maxRecordSec * 1000);

    this.mediaRecorder.ondataavailable = e => { if (e.data && e.data.size) this._chunks.push(e.data); };
    this.mediaRecorder.onstop = async () => clearTimeout(stopTimeout);
    this.mediaRecorder.start();
    return { ok: true };
  }

  async stopRecording() {
    if (!this.mediaRecorder || this.mediaRecorder.state !== 'recording') return { ok: false, error: 'Not recording' };
    const stopped = new Promise(resolve => { this.mediaRecorder.onstop = resolve; });
    this.mediaRecorder.stop();
    await stopped;

    const blob = new Blob(this._chunks, { type: 'audio/webm' });
    this.sampleBlob = blob;

    const arrayBuf = await blob.arrayBuffer().catch(() => null);
    if (!arrayBuf) return { ok: false, error: 'decode error' };

    const offline = new OfflineAudioContext(1, Math.ceil(this.sampleRate * 30), this.sampleRate);
    const decoded = await offline.decodeAudioData(arrayBuf).catch(() => null);

    this.sampleBuffer = decoded
      ? (this.#trimSilence(decoded, -50, 0.25) || decoded)
      : new AudioBuffer({ length: this.sampleRate, sampleRate: this.sampleRate, numberOfChannels: 1 });

    // Analysis & timbre
    this.voiceProfile = this.#analyzeVoice(this.sampleBuffer);
    this.timbreReady  = this.#deriveTimbre(this.sampleBuffer);

    // Build mic excitation (normalized) — if not found, we will still speak via glottal oscillator
    this.excitationReady = this.#buildExcitationBank(this.sampleBuffer);

    if (this.debug) {
      console.log('[VM v6] profile', this.voiceProfile);
      console.log('[VM v6] timbre', { mode: this.timbreMode, ready: this.timbreReady });
      console.log('[VM v6] excitation', { ready: this.excitationReady, f0: this.excitationGrainF0 });
    }

    this.mediaStream?.getTracks()?.forEach(t => t.stop());
    this.mediaStream = null;
    this.mediaRecorder = null;

    return {
      ok: true,
      blob,
      buffer: this.sampleBuffer,
      profile: this.voiceProfile,
      timbreReady: this.timbreReady,
      timbreMode: this.timbreMode,
      excitationReady: this.excitationReady
    };
  }

  calibrate() {
    if (!this.sampleBuffer) return false;
    const okT = this.#deriveTimbre(this.sampleBuffer);
    const okE = this.#buildExcitationBank(this.sampleBuffer);
    return (this.timbreReady = okT) && (this.excitationReady = okE);
  }

  /* ======================== Speak ======================== */
  async speak(text, opts = {}) {
    await this.#ensureAudioOutput(); // ensure AudioContext is running

    // Master gain
    if (!this.masterGain) {
      this.masterGain = this.audioCtx.createGain();
      this.masterGain.gain.value = Math.min(1, Math.max(0, opts.volume ?? 1));
      this.masterGain.connect(this.audioCtx.destination);
    } else {
      this.masterGain.gain.setValueAtTime(Math.min(1, Math.max(0, opts.volume ?? 1)), this.audioCtx.currentTime);
    }

    const phonemes = this.#g2p(text);
    const schedule = this.#buildPhonemeSchedule(phonemes, opts.rate, opts.pitchShift ?? 0);
    await this.#renderSchedule(schedule, true);
  }

  /* ======================== Ensure Audio Output ======================== */
  async #ensureAudioOutput() {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: this.sampleRate });
    }
    // Resume with a watchdog loop (Safari/iOS often needs user gesture; we call from button handlers)
    if (this.audioCtx.state !== 'running') {
      try { await this.audioCtx.resume(); } catch (_) {}
    }
  }

  /* ======================== Analysis ======================== */
  #analyzeVoice(buffer) {
    const sr = buffer.sampleRate;
    const ch = buffer.getChannelData(0);
    const N = Math.min(ch.length, sr * 10);
    const x = ch.subarray(0, N);

    const f0s = [];
    const hop = Math.floor(sr * 0.03);
    const wlen = Math.floor(sr * 0.06);
    for (let i = 0; i + wlen < x.length; i += hop) {
      const f0 = this.#estimateF0(x.subarray(i, i + wlen), sr, 50, 400);
      if (f0) f0s.push(f0);
    }
    const f0Mean = f0s.length ? f0s.reduce((a,b)=>a+b,0)/f0s.length : 140;
    const f0Std  = f0s.length ? Math.sqrt(f0s.reduce((a,b)=>a+(b-f0Mean)*(b-f0Mean),0)/f0s.length) : 20;

    const mags = this.#fftMag(x, sr);
    const { tiltDbPerOctave } = this.#estimateSpectralTilt(mags, sr);
    const formants = this.#estimateFormants(x, sr);
    const speakingRate = this.#estimateSpeakingRate(x, sr);

    return { f0Mean: Math.round(f0Mean), f0Std: Math.round(f0Std), spectralTilt: tiltDbPerOctave, formants, speakingRate };
  }

  #estimateF0(win, sr, minHz=50, maxHz=400) {
    const n = win.length;
    let bestLag = 0, best = 0;
    const minLag = Math.floor(sr / maxHz), maxLag = Math.floor(sr / minHz);
    for (let lag = minLag; lag <= Math.min(maxLag, n-1); lag++) {
      let s = 0; for (let i=0;i+lag<n;i++) s += win[i] * win[i+lag];
      if (s > best) { best = s; bestLag = lag; }
    }
    if (!bestLag) return null;
    const f0 = sr / bestLag;
    return (f0 < minHz || f0 > maxHz) ? null : f0;
  }

  #fftMag(x, sr) {
    let N = 1; while (N < x.length) N <<= 1;
    const re = new Float32Array(N), im = new Float32Array(N);
    re.set(x);
    const { sin, cos, PI } = Math;
    for (let k = 1; k < N; k <<= 1) {
      for (let i = 0; i < N; i += (k << 1)) {
        for (let j = 0; j < k; j++) {
          const ang = -2*PI*j/(k<<1), c = cos(ang), s = sin(ang);
          const tRe = re[i + j + k] * c - im[i + j + k] * s;
          const tIm = re[i + j + k] * s + im[i + j + k] * c;
          re[i + j + k] = re[i + j] - tRe;
          im[i + j + k] = im[i + j] - tIm;
          re[i + j] = re[i + j] + tRe;
          im[i + j] = im[i + j] + tIm;
        }
      }
    }
    const mags = new Float32Array(N/2);
    for (let i = 0; i < N/2; i++) mags[i] = Math.sqrt(re[i]*re[i] + im[i]*im[i]) + 1e-9;
    return mags;
  }

  #estimateSpectralTilt(mags, sr) {
    const n = mags.length, binHz = sr / (2*n);
    const xs = [], ys = [];
    for (let i=0;i<n;i++) {
      const f = i*binHz;
      if (f < 100 || f > sr/2) continue;
      xs.push(Math.log2(Math.max(1, f)));
      ys.push(20 * Math.log10(mags[i]));
    }
    let sx=0, sy=0, sxx=0, sxy=0;
    for (let i=0;i<xs.length;i++){ sx+=xs[i]; sy+=ys[i]; sxx+=xs[i]*xs[i]; sxy+=xs[i]*ys[i];}
    const m = (xs.length ? (xs.length*sxy - sx*sy)/(xs.length*sxx - sx*sx) : -6);
    return { tiltDbPerOctave: Math.round(m*10)/10 };
  }

  #estimateFormants(x, sr) {
    const mags = this.#fftMag(x, sr);
    const n = mags.length, binHz = sr / (2*n);
    const smooth = new Float32Array(n), w = 8;
    for (let i=0;i<n;i++){
      let s=0,c=0;
      for (let j=-w;j<=w;j++){ const k = Math.min(n-1, Math.max(0, i+j)); s+=mags[k]; c++; }
      smooth[i] = s / c;
    }
    const peaks = [];
    for (let i=1;i<n-1;i++){
      const f = i*binHz;
      if (f<200 || f>3500) continue;
      if (smooth[i] > smooth[i-1] && smooth[i] > smooth[i+1]) peaks.push({ f, a:smooth[i] });
    }
    peaks.sort((a,b)=>b.a-a.a);
    const F = peaks.slice(0,3).map(p=>Math.round(p.f));
    while (F.length < 3) F.push([700,1200,2600][F.length]);
    F.sort((a,b)=>a-b);
    return F;
  }

  #estimateSpeakingRate(x, sr) {
    const env = new Float32Array(x.length);
    const alpha = 0.98; let y = 0;
    for (let i=0;i<x.length;i++){ y = alpha*y + (1-alpha)*Math.abs(x[i]); env[i] = y; }
    let peaks = 0;
    for (let i=1;i<env.length-1;i++){
      if (env[i] > env[i-1] && env[i] > env[i+1] && env[i] > 0.05) peaks++;
    }
    const sps = peaks / (x.length / sr);
    return Math.max(4, Math.min(20, Math.round(sps)));
  }

  /* ======================== Timbre derivation ======================== */
  #deriveTimbre(buffer) {
    const okIIR = this.#deriveLPCFromBestVoiced(buffer);
    if (okIIR) { this.timbreMode = 'iir'; this.timbreReady = true; return true; }

    const sr = buffer.sampleRate;
    const ch = buffer.getChannelData(0);
    const vf = this.#findBestVoicedFrame(ch, sr);
    if (!vf) { this.timbreMode='none'; this.timbreReady=false; return false; }

    const win = ch.slice(vf.start, vf.start + vf.len);
    this.#applyHann(win);
    const okPEQ = this.#derivePeqFromFrame(win, sr);
    this.timbreMode = okPEQ ? 'peq' : 'none';
    this.timbreReady = !!okPEQ;
    return okPEQ;
  }

  #deriveLPCFromBestVoiced(buffer) {
    const sr = buffer.sampleRate;
    const x = buffer.getChannelData(0);
    if (!x || x.length < sr * 0.3) return false;

    const vf = this.#findBestVoicedFrame(x, sr);
    if (!vf) { if (this.debug) console.warn('No voiced frame found.'); return false; }

    const win = x.slice(vf.start, vf.start + vf.len);
    this.#applyHann(win);

    const pre = 0.97;
    for (let i = win.length - 1; i >= 1; i--) win[i] = win[i] - pre * win[i - 1];

    const order = this.lpcOrder;
    const R  = this.#autocorr(win, order);
    const ld = this.#levinsonDurbinStable(R, order);
    if (!Number.isFinite(ld.err) || ld.err <= 1e-8) { if (this.debug) console.warn('LPC err invalid; using PEQ fallback.'); return false; }

    // Bandwidth expansion
    const r = 0.96; for (let k=1;k<=order;k++) ld.coeffs[k] *= Math.pow(r, k);

    const a = [1]; for (let k=1;k<=order;k++) a.push(ld.coeffs[k]);
    const b = [1];
    const sumA = a.slice(1).reduce((s,v)=>s+Math.abs(v),0);
    if (!Number.isFinite(sumA) || sumA > 8) { if (this.debug) console.warn('LPC coeffs too aggressive; fallback.'); return false; }

    try { (this.audioCtx || new (window.AudioContext || window.webkitAudioContext)()).createIIRFilter(b, a); }
    catch (e) { if (this.debug) console.warn('IIR creation failed (unstable).', e); return false; }

    this.iirFeedforward = b;
    this.iirFeedback    = a;
    return true;
  }

  #derivePeqFromFrame(win, sr) {
    const mags = this.#fftMag(win, sr);
    const n = mags.length, binHz = sr / (2*n);

    const db = new Float32Array(n);
    for (let i=0;i<n;i++) db[i] = 20 * Math.log10(mags[i] + 1e-9);

    const smooth = new Float32Array(n), w = 6;
    for (let i=0;i<n;i++){
      let s=0,c=0;
      for (let j=-w;j<=w;j++){ const k = Math.min(n-1, Math.max(0, i+j)); s+=db[k]; c++; }
      smooth[i] = s / c;
    }

    const peaks = [];
    for (let i=1;i<n-1;i++){
      const f = i*binHz; if (f<150 || f>5000) continue;
      if (smooth[i] > smooth[i-1] && smooth[i] > smooth[i+1]) peaks.push({ f, db: smooth[i] });
    }
    peaks.sort((a,b)=>b.db-a.db);

    const sel = peaks.slice(0,5);
    const vals = sel.map(p=>p.db).sort((a,b)=>a-b);
    const median = vals.length ? vals[Math.floor(vals.length/2)] : -20;

    this.peqSettings = sel.map(p => ({
      freq: Math.round(p.f),
      gain: Math.max(-6, Math.min(6, p.db - median)),
      Q: 1.2
    }));
    return this.peqSettings.length > 0;
  }

  /* ======================== Mic excitation (PSOLA-style) ======================== */
  #buildExcitationBank(buffer) {
    try {
      const sr = buffer.sampleRate;
      const x = buffer.getChannelData(0);
      const vf = this.#findBestVoicedFrame(x, sr);
      if (!vf) return false;

      const win = x.slice(vf.start, vf.start + vf.len);
      this.#applyHann(win);

      // LPC residual (inverse filtering)
      const order = Math.min(this.lpcOrder, 12);
      const R  = this.#autocorr(win, order);
      const ld = this.#levinsonDurbinStable(R, order);
      if (!Number.isFinite(ld.err) || ld.err <= 1e-10) return false;

      const residual = new Float32Array(win.length);
      for (let n=0; n<win.length; n++) {
        let acc = win[n];
        for (let k=1;k<=order;k++) acc += (n-k >= 0 ? ld.coeffs[k] * win[n-k] : 0);
        residual[n] = acc;
      }

      // Pitch period & grain
      const { f0 } = this.#harmonicity(win, sr);
      const baseF0 = Math.max(60, Math.min(400, f0 || this.voiceProfile.f0Mean || 140));
      const period = Math.max(30, Math.min(win.length-1, Math.round(sr / baseF0)));

      const center = Math.floor(win.length/2);
      const start  = this.#nearestZeroCross(residual, Math.max(0, center - period));
      const len    = Math.min(residual.length - start, 2 * period);
      let grain    = residual.slice(start, start + len);
      if (grain.length < 16) return false;

      this.#applyHann(grain);

      // Normalize grain RMS to ~-12 dBFS (≈ 0.25)
      const target = 0.25;
      const rms = Math.sqrt(grain.reduce((s,v)=>s+v*v,0) / Math.max(1, grain.length));
      const scale = rms > 1e-6 ? (target / rms) : 1;
      grain = grain.map(v => v * scale);

      this.excitationGrainData = grain;
      this.excitationGrainF0   = baseF0;
      this.excitationGrainSR   = sr;
      this._excitationBufferCache = null;
      return true;
    } catch (e) {
      if (this.debug) console.warn('Excitation build failed:', e);
      return false;
    }
  }

  #nearestZeroCross(arr, fromIdx) {
    let best = fromIdx, bestAbs = Math.abs(arr[fromIdx] || 0);
    for (let i=fromIdx-50; i<=fromIdx+50; i++) {
      if (i < 1 || i >= arr.length) continue;
      const a = Math.abs(arr[i]);
      if (a < bestAbs) { bestAbs = a; best = i; }
      if (bestAbs < 1e-5) break;
    }
    return Math.max(0, Math.min(arr.length-1, best));
  }

  #getExcitationBuffer(ctx) {
    if (this._excitationBufferCache) return this._excitationBufferCache;
    if (!this.excitationGrainData) return null;

    const buf = ctx.createBuffer(1, this.excitationGrainData.length, ctx.sampleRate);
    const ch  = buf.getChannelData(0);

    if (this.excitationGrainSR === ctx.sampleRate) {
      ch.set(this.excitationGrainData);
    } else {
      const ratio = this.excitationGrainSR / ctx.sampleRate;
      for (let i=0;i<ch.length;i++) {
        const srcIdx = i * ratio;
        const i0 = Math.floor(srcIdx), i1 = Math.min(this.excitationGrainData.length-1, i0+1);
        const t  = srcIdx - i0;
        ch[i] = (1-t)*this.excitationGrainData[i0] + t*this.excitationGrainData[i1];
      }
    }

    this._excitationBufferCache = buf;
    return buf;
  }

  #psolaFromGrain(ctx, t0, dur, targetF0) {
    const out = ctx.createGain();
    const buf = this.#getExcitationBuffer(ctx);
    if (!buf) return out;

    const baseF0 = this.excitationGrainF0 || 140;
    const safeTarget = Math.max(60, Math.min(400, targetF0 || baseF0));
    const rate = Math.max(0.2, Math.min(5, baseF0 / safeTarget));
    const grainSec = buf.length / ctx.sampleRate;
    const playSec  = grainSec / rate;

    const overlap = 0.6;
    const hop = playSec * (1 - overlap);
    let t = t0;

    while (t < t0 + dur + hop) {
      const src = ctx.createBufferSource(); src.buffer = buf;
      src.playbackRate.setValueAtTime(rate, t);

      const g = ctx.createGain();
      const wRise = Math.min(0.015, playSec*0.4);
      const wFall = Math.min(0.015, playSec*0.4);
      g.gain.setValueAtTime(this._envFloor, t);
      g.gain.linearRampToValueAtTime(1.0, t + wRise);
      g.gain.setValueAtTime(1.0, t + Math.max(0.001, playSec - wFall));
      g.gain.linearRampToValueAtTime(this._envFloor, t + playSec);

      src.connect(g); g.connect(out);
      src.start(t); src.stop(t + playSec);
      t += hop;
    }

    return out;
  }

  /* ======================== G2P (Actual Words) ======================== */
  #g2p(text) {
    const cleaned = String(text || '')
      .toLowerCase()
      .replace(/[^a-z0-9 ,.'?!-]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!cleaned) return ['SP'];

    const tokens = cleaned.split(/(\s+|[,.?!])/).filter(t => t && !/^\s+$/.test(t));
    const out = [];
    for (const tok of tokens) {
      if (/^[,.?!]$/.test(tok)) { out.push('PAUSE'); continue; }
      if (/^\s+$/.test(tok)) continue;

      const base = tok.replace(/[^a-z']/g, '');
      if (!base) { out.push('SP'); continue; }

      const lex = this.lexicon.get(base);
      const phones = lex ? lex.split(' ') : this.#lts(base);

      const syllables = this.#syllabify(phones);
      for (let i = 0; i < syllables.length; i++) {
        const syl = syllables[i];
        const stressed = (i === 0 && syllables.length > 1);
        out.push(...this.#applyStress(syl, stressed));
      }
      out.push('SP'); // word boundary
    }

    // Normalize boundaries
    const normalized = [];
    for (let i=0;i<out.length;i++){
      const p = out[i];
      if (p === 'SP' && out[i+1] === 'PAUSE') continue;
      normalized.push(p);
    }
    return normalized;
  }

  #lts(w) {
    const reps = [
      [/tion$/,'SH AH N'], [/sion$/,'ZH AH N'], [/ing$/,'IH NG'],
      [/ough$/,'AH F'], [/ight$/,'AY T'], [/ear$/,'IY R'], [/air$/,'EH R'],
      [/ow$/,'OW'], [/oi/,'OY'], [/oy/,'OY'],
      [/ee/,'IY'], [/ea/,'IY'], [/oo/,'UW'], [/ou/,'AW'],
      [/ph/,'F'], [/ch/,'CH'], [/sh/,'SH'], [/th/,'TH'], [/qu/,'KW']
    ];
    let s = w;
    for (const [re, r] of reps) s = s.replace(re, ` ${r} `);
    s = s.replace(/c(?=[ei])/g, 'S').replace(/c/g, 'K');
    s = s.replace(/g(?=[ei])/g, 'J'); // soft G before e/i

    const out = [];
    const V = { a:'AE', e:'EH', i:'IH', o:'AO', u:'UH', y:'IY' };
    const C = { p:'P', t:'T', k:'K', b:'B', d:'D', g:'G', f:'F', s:'S', h:'H', m:'M', n:'N', l:'L', r:'R', w:'W', v:'V', z:'Z', j:'J', x:'K S' };
    const toks = s.split(/\s+/).filter(Boolean);

    for (const tok of toks) {
      if (/^[A-Z]{2,}$/.test(tok)) { out.push(tok); continue; } // already a phoneme cluster from replacements
      for (const ch of tok) {
        if (V[ch]) {
          let v = V[ch];
          const long = /e$/.test(w) || /([aeiouy]{2,})/.test(tok);
          if (long) v = (v==='AE')?'EY':(v==='EH')?'IY':(v==='IH')?'IY':(v==='AO')?'OW':(v==='UH')?'UW':v;
          out.push(v);
        } else if (C[ch]) {
          out.push(...C[ch].split(' '));
        } else {
          out.push('AH'); // fallback vowel ensures pronounceability
        }
      }
    }

    // Insert schwa between hard consonant clusters
    const refined = [];
    const isV = p => this._VOWELS.has(p);
    for (let i=0;i<out.length;i++){
      refined.push(out[i]);
      const a = out[i], b = out[i+1];
      if (b && !isV(a) && !isV(b)) refined.push('AH');
    }
    return refined;
  }

  #syllabify(phones) {
    const syllables = [];
    let cur = [];
    const isV = p => this._VOWELS.has(p);
    for (const p of phones) { cur.push(p); if (isV(p)) { syllables.push(cur); cur = []; } }
    if (cur.length) syllables.push(cur);
    return syllables;
  }

  #applyStress(syllable, stressed) {
    if (!stressed) return syllable;
    const out = [];
    let boosted = false;
    for (const p of syllable) {
      if (!boosted && this._VOWELS.has(p)) { out.push(p+'1'); boosted = true; }
      else out.push(p);
    }
    return out;
  }

  /* ======================== Schedule & Render ======================== */
  #buildPhonemeSchedule(phonemes, rateOverride, pitchShiftSemitones=0) {
    const baseWPM = Number.isFinite(rateOverride) ? rateOverride : 150;
    const syllPerSec = Math.max(3, Math.min(7, (baseWPM / 60) * 1.5));

    const f0Mean = this.voiceProfile.f0Mean || 140;
    const f0Std  = Math.max(6, Math.min(25, this.voiceProfile.f0Std || 20));
    const tilt   = this.voiceProfile.spectralTilt ?? -6;
    const Fuser  = this.voiceProfile.formants || [700, 1200, 2600];

    const baseFormant = (ph) => {
      const map = {
        AA:[700,1100,2500], AE:[650,1700,2600], AH:[600,1500,2500], AO:[500,900,2400],
        EH:[600,1900,2500], IH:[500,2100,2700], IY:[300,2300,3000], UH:[450,1300,2400],
        UW:[350,1000,2400], OW:[400,800,2400], EY:[500,1800,2600], AW:[800,1400,2500],
        AY:[500,1800,2600], OY:[500,1800,2600], ER:[500,1500,2000],
        L:[400,1200,2700], R:[350,1000,2600], M:[300,1000,2500], N:[350,1300,2700],
        F:[1000,2000,3500], S:[3000,4500,6500], SH:[2500,3500,5000], TH:[1400,1800,2600],
        P:[700,1100,2500], T:[700,1700,2600], K:[500,1900,2800],
        B:[700,1100,2500], D:[700,1700,2600], G:[500,1900,2800],
        H:[800,1500,2500], W:[300,800,2400], V:[1400,2200,3500], Z:[2000,3000,4500], J:[600,1800,2500],
        CH:[400,1700,2600], Y:[250,2200,3000], SP:[0,0,0], PAUSE:[0,0,0]
      };
      return map[ph] ?? [600,1600,2600];
    };

    const neutral = baseFormant('AH');
    const cents = pitchShiftSemitones * 100;
    const pitchRatio = Math.pow(2, cents/1200) * (f0Mean / 140);
    const scale = [Fuser[0]/neutral[0], Fuser[1]/neutral[1], Fuser[2]/neutral[2]];

    const sch = [];
    let prevFormants = baseFormant('AH').map((f,i)=>Math.round(f*scale[i]*pitchRatio));
    const now = this.audioCtx ? this.audioCtx.currentTime : 0;

    for (const ph0 of phonemes) {
      let ph = ph0, stressed = false;
      if (/\d$/.test(ph)) { stressed = true; ph = ph.replace(/\d$/,''); }

      const isPause    = (ph === 'PAUSE');
      const isVowel    = this._VOWELS.has(ph);
      const isFricative= ['F','S','SH','TH','H','V','Z'].includes(ph);
      const isPlosive  = ['P','T','K','B','D','G','CH','J'].includes(ph);
      const isNasal    = ['M','N'].includes(ph);

      let dur = 0.12;
      if (ph === 'SP')       dur = 0.06;
      else if (isPause)      dur = 0.25;
      else if (isVowel)      dur = stressed ? 0.18 : 0.14;
      else if (isFricative)  dur = 0.12;
      else if (isPlosive)    dur = 0.10;
      else if (isNasal)      dur = 0.12;

      const base = baseFormant(ph);
      const targetFormants = [
        Math.max(180, Math.round(base[0] * scale[0] * pitchRatio)),
        Math.max(300, Math.round(base[1] * scale[1] * pitchRatio)),
        Math.max(800, Math.round(base[2] * scale[2] * pitchRatio)),
      ];

      const glide = Math.max(0.04, dur * (isVowel ? 0.6 : 0.4));
      const f0    = isVowel ? (f0Mean + (Math.random()-0.5)*f0Std) : null;

      sch.push({
        at: 0,
        phoneme: ph,
        duration: dur,
        glide,
        f0,
        formantsFrom: prevFormants,
        formantsTo: targetFormants,
        tilt: this.voiceProfile.spectralTilt ?? -6,
        flags: { isVowel, isFricative, isPlosive, isNasal, isPause }
      });

      if (!isPause && ph !== 'SP') prevFormants = targetFormants;
      else prevFormants = baseFormant('AH').map((f,i)=>Math.round(f*scale[i]*pitchRatio));
    }

    let t = now + 0.10; // small offset for safety
    for (const s of sch) { s.at = t; t += s.duration; }
    return sch;
  }

  async #renderSchedule(schedule, monitor = true) {
    const ctx = this.audioCtx;
    const destination = this.masterGain;

    // Gentle compressor
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.setValueAtTime(-20, ctx.currentTime);
    comp.knee.setValueAtTime(8, ctx.currentTime);
    comp.ratio.setValueAtTime(2.2, ctx.currentTime);
    comp.attack.setValueAtTime(0.012, ctx.currentTime);
    comp.release.setValueAtTime(0.12, ctx.currentTime);
    if (monitor) comp.connect(destination);

    const lastIdx = schedule.map((s,i)=>({s,i})).reverse().find(({s})=>s.flags.isPause)?.i ?? schedule.length-1;

    for (let i=0;i<schedule.length;i++) {
      const step = schedule[i];
      const t0 = step.at;
      const dur = Math.max(0.05, step.duration);
      const t1 = t0 + dur;

      if (step.flags.isPause || step.phoneme === 'SP') continue;

      // === Source selection (always audible) ===
      let sourceOut;
      const gainNode = ctx.createGain();
      // Slightly higher base gain if mic excitation is used
      const baseGain = this.excitationReady ? 0.35 : 0.24;
      gainNode.gain.value = baseGain;

      if (step.flags.isFricative) {
        // Band-limited noise
        const noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
        const data = noiseBuf.getChannelData(0);
        let z = 0; for (let i2=0;i2<data.length;i2++){ z = 0.92*z + 0.08*(Math.random()*2-1); data[i2] = z; }
        const noise = ctx.createBufferSource(); noise.buffer = noiseBuf;
        sourceOut = ctx.createGain();
        noise.connect(sourceOut);
        noise.start(t0); noise.stop(t1);

      } else if (step.flags.isPlosive) {
        // Burst + brief voiced tail (guarantees audible energy)
        const burst = ctx.createBuffer(1, Math.floor(ctx.sampleRate * Math.min(0.06,dur)), ctx.sampleRate);
        const d = burst.getChannelData(0);
        for (let k=0;k<d.length;k++) d[k] = (Math.random()*2-1) * Math.exp(-k/(d.length*0.25));
        const burstSrc = ctx.createBufferSource(); burstSrc.buffer = burst;

        sourceOut = ctx.createGain();
        burstSrc.connect(sourceOut);
        burstSrc.start(t0);
        burstSrc.stop(t0 + Math.min(0.06,dur));

        // voiced tail for B/D/G/J (or even all plosives for audibility)
        const tail = this.excitationReady
          ? this.#psolaFromGrain(ctx, t0 + 0.02, Math.max(0, t1 - (t0 + 0.02)), step.f0 || this.voiceProfile.f0Mean)
          : this.#glottalOsc(ctx, Math.max(60, Math.min(320, step.f0 || 140)), step.tilt);
        tail.connect(sourceOut);

      } else {
        // Vowels / voiced consonants
        if (this.excitationReady) {
          sourceOut = this.#psolaFromGrain(ctx, t0, dur, step.f0 || this.voiceProfile.f0Mean);
        } else {
          const osc = this.#glottalOsc(ctx, Math.max(60, Math.min(320, step.f0 || 140)), step.tilt);
          sourceOut = osc; // will be filtered below
        }
      }

      // === Formants & chain (wider F1 for energy) ===
      const bp1 = ctx.createBiquadFilter(); bp1.type='bandpass'; bp1.Q.value = this.excitationReady ? 4.5 : 5.5;
      const bp2 = ctx.createBiquadFilter(); bp2.type='bandpass'; bp2.Q.value = 7.0;
      const bp3 = ctx.createBiquadFilter(); bp3.type='bandpass'; bp3.Q.value = 8.5;

      const notch = ctx.createBiquadFilter(); notch.type = 'notch';
      notch.frequency.value = step.flags.isNasal ? 900 : 1200; notch.Q.value = step.flags.isNasal ? 3.0 : 0.4;

      const tiltShelf = ctx.createBiquadFilter(); tiltShelf.type='highshelf';
      tiltShelf.gain.setValueAtTime(Math.max(-12, Math.min(0, step.tilt)), t0);
      tiltShelf.frequency.setValueAtTime(2500, t0);

      const lowpass = ctx.createBiquadFilter(); lowpass.type='lowpass';
      lowpass.frequency.setValueAtTime(6000, t0); lowpass.Q.value = 0.7;

      // Envelope (with floor to avoid total silence)
      const env = gainNode.gain;
      env.cancelScheduledValues(t0);
      env.setValueAtTime(this._envFloor, t0);
      env.linearRampToValueAtTime(baseGain, t0 + Math.min(0.05, dur*0.22));
      env.setValueAtTime(baseGain * 0.9, t0 + Math.max(0.10, dur*0.55));
      env.linearRampToValueAtTime(this._envFloor, t1);

      // Coarticulation (formant glides)
      const [fA1,fA2,fA3] = step.formantsFrom;
      const [fB1,fB2,fB3] = step.formantsTo;
      bp1.frequency.setValueAtTime(fA1, t0); bp2.frequency.setValueAtTime(fA2, t0); bp3.frequency.setValueAtTime(fA3, t0);
      bp1.frequency.linearRampToValueAtTime(fB1, t0 + step.glide);
      bp2.frequency.linearRampToValueAtTime(fB2, t0 + step.glide);
      bp3.frequency.linearRampToValueAtTime(fB3, t0 + step.glide);

      // Timbre coloration
      let colorOut = lowpass;
      if (this.timbreMode === 'iir' && this.timbreReady && this.iirFeedback && this.iirFeedforward) {
        try { const iir = ctx.createIIRFilter(this.iirFeedforward, this.iirFeedback); colorOut.connect(iir); colorOut = iir; }
        catch (e) { this.timbreReady = false; this.timbreMode = 'none'; if (this.debug) console.warn('IIR failed at render', e); }
      } else if (this.timbreMode === 'peq' && this.timbreReady && Array.isArray(this.peqSettings) && this.peqSettings.length) {
        let last = colorOut;
        for (const s of this.peqSettings) {
          const peq = ctx.createBiquadFilter(); peq.type='peaking';
          peq.frequency.setValueAtTime(s.freq, t0); peq.Q.value = s.Q; peq.gain.setValueAtTime(s.gain, t0);
          last.connect(peq); last = peq;
        }
        colorOut = last;
      }

      // Connect chain
      const sumGain = ctx.createGain();
      sourceOut.connect(bp1); sourceOut.connect(bp2); sourceOut.connect(bp3);
      bp1.connect(sumGain); bp2.connect(sumGain); bp3.connect(sumGain);
      sumGain.connect(gainNode);
      gainNode.connect(tiltShelf);
      tiltShelf.connect(notch);
      notch.connect(lowpass);
      colorOut.connect(comp);

      // End-of-phrase pitch fall for naturalness (oscillator only)
      if (i >= lastIdx - 1 && step.f0 && 'frequency' in sourceOut) {
        const f = sourceOut.frequency;
        const endF = Math.max(60, (step.f0 || 140) * 0.92);
        f.setValueAtTime(step.f0 || 140, t0);
        f.linearRampToValueAtTime(endF, t1);
      }
    }
  }

  /* ======================== Fallback glottal oscillator ======================== */
  #glottalOsc(ctx, f0, tiltDbPerOctave) {
    const osc = ctx.createOscillator();
    const harmonics = 32;
    const real = new Float32Array(harmonics+1);
    const imag = new Float32Array(harmonics+1);
    const tiltPerH = Math.pow(10, (tiltDbPerOctave ?? -6) / 20);
    for (let n=1;n<=harmonics;n++){
      const amp = (1/n) * Math.pow(tiltPerH, Math.log2(n));
      real[n] = 0; imag[n] = amp; // saw-ish spectrum
    }
    const pw = ctx.createPeriodicWave(real, imag, { disableNormalization: false });
    osc.setPeriodicWave(pw);
    osc.frequency.setValueAtTime(f0, ctx.currentTime);
    return osc;
  }

  /* ======================== Utilities ======================== */
  exportProfile() { return JSON.stringify(this.voiceProfile); }
  importProfile(json) {
    try {
      const p = JSON.parse(json);
      if (p && Array.isArray(p.formants) && typeof p.f0Mean === 'number') {
        this.voiceProfile = Object.assign({}, this.voiceProfile, p);
        return true;
      }
    } catch (_) {}
    return false;
  }

  #trimSilence(buffer, threshDb=-50, padSec=0.2) {
    const sr = buffer.sampleRate;
    const x = buffer.getChannelData(0);
    const N = x.length;
    const win = Math.max(1, Math.floor(sr * 0.02));
    const rmsAt = (i) => {
      let s=0, len = Math.min(win, N - i);
      for (let k=0;k<len;k++) s += x[i+k] * x[i+k];
      return Math.sqrt(s / Math.max(1, len));
    };
    const thresh = Math.pow(10, threshDb / 20);
    let start=0, end=N-1;
    for (let i=0;i<N;i+=Math.max(1, Math.floor(sr*0.01))) { if (rmsAt(i) > thresh) { start=i; break; } }
    for (let i=N-1;i>0;i-=Math.max(1, Math.floor(sr*0.01))) { if (rmsAt(i) > thresh) { end=i; break; } }
    if (end <= start) return buffer;
    const sPad = Math.max(0, start - Math.floor(sr * padSec));
    const ePad = Math.min(N, end + Math.floor(sr * padSec));
    const outLen= ePad - sPad;
    if (outLen <= 0) return buffer;
    const out = new AudioBuffer({ length: outLen, sampleRate: sr, numberOfChannels: 1 });
    const dest = out.getChannelData(0);
    dest.set(x.subarray(sPad, ePad), 0);
    return out;
  }

  #rms(arr) { let s=0; for (let i=0;i<arr.length;i++) s += arr[i]*arr[i]; return Math.sqrt(s / Math.max(1, arr.length)); }
  #zcr(slice, sr) {
    let crossings = 0;
    for (let i=1;i<slice.length;i++){
      const a = slice[i-1], b = slice[i];
      if ((a >= 0 && b < 0) || (a < 0 && b >= 0)) crossings++;
    }
    return crossings * (sr / slice.length);
  }

  #harmonicity(win, sr) {
    const n = win.length;
    const minLag = Math.floor(sr / 400), maxLag = Math.floor(sr / 50);
    let best = 0, bestLag = 0;
    for (let lag=minLag; lag<=Math.min(maxLag, n-1); lag++) {
      let num=0, denomA=0, denomB=0;
      for (let i=0;i+lag<n;i++){ const a = win[i], b = win[i+lag]; num+=a*b; denomA+=a*a; denomB+=b*b; }
      const r = num / Math.sqrt(Math.max(1e-9, denomA * denomB));
      if (r > best) { best = r; bestLag = lag; }
    }
    return { harm: best, f0: bestLag ? sr / bestLag : null };
  }

  #findBestVoicedFrame(x, sr) {
    const frame = Math.floor(sr * 0.08);
    const hop   = Math.floor(sr * 0.02);
    let bestScore = 0, bestIdx = -1;
    for (let i=0;i+frame<x.length;i+=hop) {
      const slice = x.subarray(i, i+frame);
      const rms = this.#rms(slice);
      if (rms < 0.01) continue;
      const { harm, f0 } = this.#harmonicity(slice, sr);
      const zcrHz = this.#zcr(slice, sr) / 2;
      const periodic = (f0 && harm > 0.6);
      const zcrOk    = (zcrHz > 50 && zcrHz < 400);
      const score = (rms * 0.5) + (periodic ? harm : 0) + (zcrOk ? 0.2 : 0);
      if (score > bestScore) { bestScore = score; bestIdx = i; }
    }
    return bestIdx >= 0 ? { start: bestIdx, len: Math.floor(sr * 0.08) } : null;
  }

  #applyHann(arr) {
    const N = arr.length;
    for (let n=0;n<N;n++) arr[n] *= (0.5 - 0.5 * Math.cos((2*Math.PI*n)/(N-1)));
  }

  #autocorr(x, order) {
    const R = new Float32Array(order+1);
    for (let lag=0; lag<=order; lag++){
      let sum = 0;
      for (let n=0; n<x.length-lag; n++) sum += x[n] * x[n+lag];
      R[lag] = sum;
    }
    return R;
  }

  #levinsonDurbinStable(R, order) {
    const a = new Float32Array(order + 1);
    const k = new Float32Array(order + 1);
    let E = R[0];
    if (!Number.isFinite(E) || E <= 1e-12) return { coeffs: a, err: 0, refl: k };
    for (let i = 1; i <= order; i++) {
      let acc = R[i];
      for (let j = 1; j < i; j++) acc += a[j] * R[i - j];
      let ki = -acc / E;
      const maxRef = 0.98;
      if (!Number.isFinite(ki)) ki = 0;
      if (Math.abs(ki) >= maxRef) ki = Math.sign(ki) * maxRef;
      k[i] = ki;
      a[i] = ki;
      for (let j = 1; j < i; j++) a[j] = a[j] + ki * a[i - j];
      E = E * (1 - ki * ki);
      if (!Number.isFinite(E) || E <= 1e-12) { E = 1e-12; break; }
    }
    return { coeffs: a, err: E, refl: k };
  }
};