<?php
header("Content-Type: application/json; charset=utf-8");
include_once dirname(__DIR__,2)."/libs/polldb.php";
global $results;
// Ensure it's always a string
if (!isset($results)) 
    $results = json_encode(['error' => 'No data received'], JSON_UNESCAPED_SLASHES);
echo $results;