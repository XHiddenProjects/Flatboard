
// particles.js
(function () {
  'use strict';

  // 1) Choose the particle scene name.
  //    Priority: global constant -> container data attribute -> default "Rain"
  const defaultName = 'Rain';
  const container = document.querySelector('[data-particles-container]') || document.getElementById('particles-root') || document.body;

  // 2) Guard: require engine + scenes map
  if (typeof window.ParticleJS === 'undefined' || typeof window.ParticleScene === 'undefined') {
    console.error('Particle engine not found. Include particleslib.min.js first.');
    return;
  }
  if (!window.particleFunctions || typeof window.particleFunctions[PARTICLE_NAME] !== 'function') {
    console.error(`Scene "${PARTICLE_NAME}" is not defined in particleFunctions.js.`);
    return;
  }

  // 3) Create the engine and apply the selected scene
  const engine = new ParticleJS(container, {
    // You can set a global background here; per-scene background will override after setScene.
    background: 'transparent'
  });

  // Build the scene from the factory and apply it
  const sceneFactory = window.particleFunctions[PARTICLE_NAME];
  const scene = sceneFactory(); // returns a ParticleScene
  engine.setScene(scene);       // reinitialize with scene options
  engine.play();                // start the animation loop

  document.querySelector('form:has(input[name="plugin"][value="particles"])').addEventListener('submit',()=>setTimeout(()=>window.location.reload(),3000));

})();
