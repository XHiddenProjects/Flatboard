<?php
namespace App\Plugins\Particles;
use App\Core\Plugin;
use App\Core\PluginHelper;
use App\Helpers\PluginAssetHelper;
class Particles{
    public function boot(): void{
        Plugin::hook('view.footer.scripts', [$this, 'loadScripts']);        
    }
    public function loadScripts(&$scripts): void{
        $scripts[] = PluginAssetHelper::loadJs('particles', 'assets/js/particleslib.min.js');
        $data = Plugin::getData('particles',null,[]);
        $scripts[] = "<script>const PARTICLE_NAME = '{$data['select_particles']}'</script>";
        $scripts[] = PluginAssetHelper::loadJs('particles', 'assets/js/particleFunctions.js');
        $scripts[] = PluginAssetHelper::loadJs('particles', 'assets/js/particles.js');
    }
    private function getTranslations(): array{
        return PluginHelper::getTranslations('particles');
    }
}