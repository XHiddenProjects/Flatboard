
// particleFunctions.js

(function () {
  'use strict';

  // Ensure the engine globals exist (provided by particleslib.min.js)
  if (typeof window.ParticleScene === 'undefined' || typeof window.ParticleJS === 'undefined') {
    throw new Error('Particle engine is not loaded. Include particleslib.min.js before particleFunctions.js.');
  }

  /**
   * Rain — fast falling droplets
   */
  function createRainScene() {
    return new ParticleScene('Rain', {
      background: 'transparent',
      particles: {
        number: { value: 100, density: { enable: true, value_area: 800 }, max: 400 },
        color: { value: '#9ec9ff' },
        shape: { type: 'circle', stroke: { width: 0 } },
        opacity: { value: 0.8, random: true },
        size: { value: 2.2, random: true },
        line_linked: { enable: false },
        physics: { drag: 0.996, gravity: 120 },
        move: {
          enable: true,
          speed: [8, 14],
          direction: 'bottom',
          random: false,
          straight: true,
          out_mode: 'out',
          behavior: 'default'
        }
      },
      interactivity: {
        events: { onhover: { enable: false }, onclick: { enable: false }, resize: true }
      }
    });
  }

  /**
   * Snow — slow drifting flakes
   */
  function createSnowScene() {
    return new ParticleScene('Snow', {
      background: 'transparent',
      particles: {
        number: { value: 80, density: { enable: true, value_area: 900 }, max: 300 },
        color: { value: '#ffffff' },
        shape: { type: 'circle', stroke: { width: 0 } },
        opacity: { value: 0.9, random: true },
        size: { value: 3.5, random: true },
        line_linked: { enable: false },
        physics: { drag: 0.995, gravity: 18 },
        move: {
          enable: true,
          speed: [0.6, 1.4],
          direction: 'none',
          random: true,
          straight: false,
          out_mode: 'out',
          behavior: 'swirl',   // gentle swirl around center
          swirl: { strength: 10 }
        }
      },
      interactivity: {
        events: { onhover: { enable: false }, onclick: { enable: false }, resize: true }
      }
    });
  }

  /**
   * Confetti — colorful pieces floating and exiting
   */
  function createConfettiScene() {
    return new ParticleScene('Confetti', {
      background: 'transparent',
      particles: {
        number: { value: 140, density: { enable: true, value_area: 700 }, max: 260 },
        color: { value: ['#ff6b6b', '#ffd93d', '#6bcB77', '#4d96ff', '#b76eff'] },
        shape: { type: 'polygon', stroke: { width: 0 }, polygon: { nb_sides: 5 } },
        opacity: { value: 0.95, random: true },
        size: { value: 4.5, random: true },
        line_linked: { enable: false },
        physics: { drag: 0.992, gravity: 40 },
        move: {
          enable: true,
          speed: [1.2, 2.8],
          direction: 'none',
          random: true,
          straight: false,
          out_mode: 'out',
          behavior: 'default'
        }
      },
      interactivity: {
        events: {
          onhover: { enable: true, mode: 'bubble' }, // hover to liven up
          onclick: { enable: true, mode: 'push' },    // click to add more
          resize: true
        },
        modes: {
          bubble: { distance: 120, size: 8, duration: 0.6, opacity: 1, speed: 2 },
          push: { particles_nb: 12 }
        }
      }
    });
  }

/**
 * Fireworks — rockets with tail + auto explosion; no generic falling particles
 */
function createFireworksScene() {
  return new ParticleScene('Fireworks', function (engine) {
    // ---- Tuning
    const PALETTE = ['#ffd166', '#ef476f', '#06d6a0', '#118ab2', '#f3722c', '#ffe66d'];
    const ROCKET = { thrust: 220, minVy: -120, maxVy: -280 }; // upward (negative vy)
    const TRAIL = { life: 0.65, rateSec: 0.06, size: [1.2, 2.0], opacity: 0.9 };
    const SPARKS = { countMin: 50, countMax: 90, lifeMin: 1.6, lifeMax: 2.5, speedMin: 70, speedMax: 250, sizeMin: 1.6, sizeMax: 3.4 };

    // Controller state
    engine._fw = { nextEmitAt: 0, emitInterval: 1.8, rocketsPerBurst: 2, trailAccumulator: 0 };

    // Keep references
    const baseStep = engine._step.bind(engine);
    const baseUpdate = engine._updateParticle.bind(engine);

    // Helpers
    const randBetween = (a, b) => a + Math.random() * (b - a);
    const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

    function emitRocket() {
      const w = engine.canvas.width, h = engine.canvas.height, dpr = engine.dpr;
      const x = w * 0.15 + Math.random() * w * 0.7;  // near center
      const y = h - 6;                                // bottom launch
      const vx = (Math.random() - 0.5) * 50 * dpr;    // slight horizontal drift
      const vy = randBetween(ROCKET.minVy, ROCKET.maxVy) * dpr;

      const explodeY = randBetween(h * 0.12, h * 0.45);

      engine.particles.push({
        x, y, vx, vy, ax: 0, ay: 0,
        size: 3.5, baseSize: 3.5,
        opacity: 1, baseOpacity: 1,
        fillStyle: '#fffbe6',
        strokeStyle: null, image: null,
        _kind: 'rocket',
        _explodeY: explodeY
      });
    }

    function spawnTrail(rocket, dt) {
      engine._fw.trailAccumulator += dt;
      const dpr = engine.dpr;
      while (engine._fw.trailAccumulator >= TRAIL.rateSec) {
        engine._fw.trailAccumulator -= TRAIL.rateSec;
        const size = randBetween(TRAIL.size[0], TRAIL.size[1]);
        engine.particles.push({
          x: rocket.x,
          y: rocket.y + 2,
          vx: rocket.vx * 0.15 + (Math.random() - 0.5) * 20 * dpr,
          vy: rocket.vy * 0.15 + randBetween(10, 40) * dpr,
          ax: 0, ay: 0,
          size, baseSize: size,
          opacity: TRAIL.opacity, baseOpacity: TRAIL.opacity,
          fillStyle: '#ffd166',
          strokeStyle: null, image: null,
          _kind: 'trail',
          _life: TRAIL.life, _lifeMax: TRAIL.life
        });
      }
    }

    function explode(rocket) {
      const dpr = engine.dpr;
      const count = Math.floor(randBetween(SPARKS.countMin, SPARKS.countMax));
      for (let i = 0; i < count; i++) {
        const a = Math.random() * Math.PI * 2;
        const speed = randBetween(SPARKS.speedMin, SPARKS.speedMax) * dpr;
        engine.particles.push({
          x: rocket.x, y: rocket.y,
          vx: Math.cos(a) * speed,
          vy: Math.sin(a) * speed,
          ax: 0, ay: 0,
          size: randBetween(SPARKS.sizeMin, SPARKS.sizeMax),
          baseSize: 2.4,  // base for fade math; visual size above
          opacity: 1, baseOpacity: 1,
          fillStyle: pick(PALETTE),
          strokeStyle: null, image: null,
          _kind: 'spark',
          _life: randBetween(SPARKS.lifeMin, SPARKS.lifeMax),
          _lifeMax: 2.0
        });
      }
    }

    // Per-particle custom update + native physics
    engine._updateParticle = function (p, dt) {
      if (p._kind === 'rocket') {
        p.vy -= (ROCKET.thrust * this.dpr) * dt; // upward thrust
        p.opacity = p.baseOpacity;               // keep bright head
        p.size = p.baseSize;
      } else if (p._kind === 'trail') {
        p._life -= dt;
        const k = Math.max(0, p._life / p._lifeMax);
        p.opacity = p.baseOpacity * k;
        p.size = Math.max(0.6, p.baseSize * k);
        if (p._life <= 0) p._dead = true;
      } else if (p._kind === 'spark') {
        p._life -= dt;
        const k = Math.max(0, p._life / p._lifeMax);
        p.opacity = p.baseOpacity * k;
        p.size = Math.max(0.8, p.baseSize * k);
        if (p._life <= 0) p._dead = true;
      }
      // Run native physics/render path
      baseUpdate(p, dt);
    };

    // Emit rockets, spawn tails, explode at apex, cleanup
    engine._step = function (dt) {
      // Emit
      this._fw.nextEmitAt -= dt;
      if (this._fw.nextEmitAt <= 0) {
        this._fw.nextEmitAt = this._fw.emitInterval;
        for (let i = 0; i < this._fw.rocketsPerBurst; i++) emitRocket();
      }

      // Tails
      for (const p of this.particles) if (p._kind === 'rocket') spawnTrail(p, dt);

      // Native step
      baseStep(dt);

      // Explode near apex & cleanup
      for (const p of this.particles) {
        if (p._kind === 'rocket') {
          const slowed = Math.abs(p.vy) < 5;
          const reachedRandomHeight = p._explodeY != null && p.y < p._explodeY;
          const turnedDown = p.vy > 0;

          // explode when it reaches its own random height OR at apex fallback
          if (reachedRandomHeight || slowed || turnedDown) {
            explode(p);
            p._dead = true;
          }
        }
      }
      this.particles = this.particles.filter(q => !q._dead);
    };

    // Return options: **zero** auto-particles
    return {
      background: 'transparent',
      particles: {
        number: { value: 0, density: { enable: false }, max: 600 }, // <-- NO GENERIC PARTICLES
        color: { value: PALETTE },
        shape: { type: 'circle', stroke: { width: 0 } },
        opacity: { value: 1, random: false },
        size: { value: 3, random: true },
        line_linked: { enable: false },
        physics: { drag: 0.985, gravity: 120 }, // gravity affects sparks/trails; rockets use thruster
        move: {
          enable: true,
          speed: [0.4, 1.2],
          direction: 'none',
          random: true,
          straight: false,
          out_mode: 'out',
          behavior: 'default' // we fully control rockets; keep default for sparks/trails
        }
      },
      interactivity: {
        events: { onhover: { enable: false }, onclick: { enable: false, mode: null}, resize: true }
      }
    };
  });
}


function createFirefliesScene() {
  return new ParticleScene('Fireflies', {
    background: 'transparent',
    particles: {
      number: { value: 80, density: { enable: true, value_area: 900 }, max: 300 },
      color: { value: ['#fff08a', '#ffe26a', '#ffd54f'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.9, random: true },
      size: { value: 2.6, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.995, gravity: 0 },
      move: {
        enable: true,
        speed: [0.2, 0.8],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'swirl',
        swirl: { strength: 20 }
      }
    },
    interactivity: {
      events: { onhover: { enable: true, mode: 'bubble' }, onclick: { enable: false }, resize: true },
      modes: { bubble: { distance: 100, size: 5, duration: 0.5, opacity: 1, speed: 2 } }
    }
  });
}

function createStarfieldScene() {
  return new ParticleScene('Starfield', {
    background: 'transparent',
    particles: {
      number: { value: 140, density: { enable: true, value_area: 1000 }, max: 400 },
      color: { value: ['#ffffff', '#cfe6ff', '#ffe7cf'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.9, random: true, anim: { enable: true, speed: 0.6, opacity_min: 0.2, sync: false } },
      size: { value: 1.2, random: true, anim: { enable: true, speed: 20, size_min: 0.8, sync: false } },
      line_linked: { enable: false },
      physics: { drag: 0.996, gravity: 0 },
      move: {
        enable: true,
        speed: [0.05, 0.2],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'default'
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: false }, resize: true } }
  });
}

function createBubblesScene() {
  return new ParticleScene('Bubbles', {
    background: 'transparent',
    particles: {
      number: { value: 60, density: { enable: true, value_area: 900 }, max: 260 },
      color: { value: ['#8fd3fe', '#a6e3ff', '#d1f1ff'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.7, random: true },
      size: { value: 6, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.995, gravity: 0 },
      move: {
        enable: true,
        speed: [30, 50],
        direction: 'top',
        random: false,
        straight: true,
        out_mode: 'out',
        behavior: 'default'
      }
    },
    interactivity: {
      events: { onhover: { enable: true, mode: 'bubble' }, onclick: { enable: true, mode: 'push' }, resize: true },
      modes: { bubble: { distance: 120, size: 10, duration: 0.6, opacity: 1, speed: 2 }, push: { particles_nb: 6 } }
    }
  });
}

function createAuroraScene() {
  return new ParticleScene('Aurora', {
    background: 'transparent',
    particles: {
      number: { value: 80, density: { enable: true, value_area: 900 }, max: 300 },
      color: { value: ['#7ef29a', '#5be694', '#49c3f1', '#a0ffea'] },
      shape: { type: 'edge', stroke: { width: 0 } },
      opacity: { value: 0.5, random: true },
      size: { value: 5, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.992, gravity: 0 },
      move: {
        enable: true,
        speed: [0.4, 0.9],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'swirl',
        swirl: { strength: 80 }
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: false }, resize: true } }
  });
}

function createNebulaScene() {
  return new ParticleScene('Nebula', {
    background: 'transparent',
    particles: {
      number: { value: 70, density: { enable: true, value_area: 1100 }, max: 240 },
      color: { value: ['#b76eff', '#ff6bcb', '#f3722c', '#4d96ff', '#ffd93d'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.35, random: true },
      size: { value: 10, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.993, gravity: 0 },
      move: {
        enable: true,
        speed: [0.1, 0.5],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'swirl',
        swirl: { strength: 40 }
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: false }, resize: true } }
  });
}

function createSparksScene() {
  return new ParticleScene('Sparks', {
    background: 'transparent',
    particles: {
      number: { value: 160, density: { enable: true, value_area: 800 }, max: 320 },
      color: { value: ['#ffb703', '#fb8500', '#ffd166'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 1, random: true },
      size: { value: 2, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.985, gravity: 80 },
      move: {
        enable: true,
        speed: [3, 6],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'default'
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: true, mode: 'explode' }, resize: true },
      modes: { explode: { power: 260 } } }
  });
}

function createDustScene() {
  return new ParticleScene('Dust', {
    background: 'transparent',
    particles: {
      number: { value: 200, density: { enable: true, value_area: 1200 }, max: 400 },
      color: { value: ['#c9c9c9', '#e4e4e4', '#d8d8d8'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.4, random: true },
      size: { value: 1.4, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.996, gravity: 0 },
      move: {
        enable: true,
        speed: [0.05, 0.18],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'default'
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: false }, resize: true } }
  });
}

function createMeteorShowerScene() {
  return new ParticleScene('Meteor Shower', {
    background: 'transparent',
    particles: {
      number: { value: 60, density: { enable: true, value_area: 900 }, max: 240 },
      color: { value: ['#ffffff', '#ffd166', '#ef476f'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.9, random: true },
      size: { value: 2.8, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.993, gravity: 40 },
      move: {
        enable: true,
        speed: [6, 12],
        direction: 'bottom-right',
        random: false,
        straight: true,
        out_mode: 'out',
        behavior: 'default'
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: false }, resize: true } }
  });
}

function createOrbitalsScene() {
  return new ParticleScene('Orbitals', {
    background: 'transparent',
    particles: {
      number: { value: 80, density: { enable: true, value_area: 900 }, max: 300 },
      color: { value: ['#4d96ff', '#06d6a0', '#ffd166'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.9, random: false },
      size: { value: 2.2, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.992, gravity: 0 },
      move: {
        enable: true,
        speed: [0.8, 1.6],
        direction: 'none',
        random: false,
        straight: false,
        out_mode: 'out',
        behavior: 'default',
        attract: { enable: true, rotateX: 1200, rotateY: 1200 }
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: false }, resize: true } }
  });
}

function createWaveDotsScene() {
  return new ParticleScene('Wave Dots', {
    background: 'transparent',
    particles: {
      number: { value: 100, density: { enable: true, value_area: 900 }, max: 320 },
      color: { value: '#9ec9ff' },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.8, random: false },
      size: { value: 2.6, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.994, gravity: 0 },
      move: {
        enable: true,
        speed: [0.8, 1.2],
        direction: 'none',
        random: false,
        straight: false,
        out_mode: 'out',
        behavior: 'slide',
        slide: { stiffness: 3 }
      }
    },
    interactivity: { events: { onhover: { enable: true, mode: 'slide' }, onclick: { enable: false }, resize: true } }
  });
}

function createSwarmScene() {
  return new ParticleScene('Swarm', {
    background: 'transparent',
    particles: {
      number: { value: 120, density: { enable: true, value_area: 900 }, max: 360 },
      color: { value: ['#6bcB77', '#4d96ff', '#ffd93d'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.9, random: true },
      size: { value: 2.4, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.992, gravity: 0 },
      move: {
        enable: true,
        speed: [1, 2.4],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'default',
        attract: { enable: true, rotateX: 600, rotateY: 1200 }
      }
    },
    interactivity: {
      events: { onhover: { enable: true, mode: 'repulse' }, onclick: { enable: false }, resize: true },
      modes: { repulse: { distance: 100, duration: 0.4 } }
    }
  });
}

function createGlimmerScene() {
  return new ParticleScene('Glimmer', {
    background: 'transparent',
    particles: {
      number: { value: 130, density: { enable: true, value_area: 900 }, max: 340 },
      color: { value: ['#ffffff', '#ffe7cf', '#eaf1ff'] },
      shape: { type: 'circle', stroke: { width: 0 } },
      opacity: { value: 0.9, random: true, anim: { enable: true, speed: 2, opacity_min: 0.2, sync: false } },
      size: { value: 2.4, random: true },
      line_linked: { enable: false },
      physics: { drag: 0.995, gravity: 0 },
      move: {
        enable: true,
        speed: [0.3, 1.1],
        direction: 'none',
        random: true,
        straight: false,
        out_mode: 'out',
        behavior: 'default'
      }
    },
    interactivity: { events: { onhover: { enable: false }, onclick: { enable: false }, resize: true } }
  });
}





  // Export to global (so particles.js can pick the right one by name)
  window.particleFunctions = {
    rain: createRainScene,
    snow: createSnowScene,
    confetti: createConfettiScene,
    fireworks: createFireworksScene,
    fireflies: createFirefliesScene,
    starfield: createStarfieldScene,
    bubbles: createBubblesScene,
    aurora: createAuroraScene,
    nebula: createNebulaScene,
    sparks: createSparksScene,
    dust: createDustScene,
    meteorShower: createMeteorShowerScene,
    orbitals: createOrbitalsScene,
    waveDots: createWaveDotsScene,
    swarm: createSwarmScene,
    glimmer: createGlimmerScene
  };
})();