<?php
namespace App\Plugins\Polls;

use App\Core\Plugin;
use App\Core\PluginHelper;
use App\Core\Session;
use App\Helpers\PluginAssetHelper;
use App\Helpers\UrlHelper;

include_once dirname(__FILE__).'/libs/polldb.php';
class PollsPlugin{
    public function __construct() {

    }
    public function boot(){
        Plugin::hook('markdown.editor.config',[$this,'configureEditor']);
        Plugin::hook('view.header.styles', [$this, 'loadStyles']);
        Plugin::hook('view.footer.scripts', [$this, 'loadScripts']);
        Plugin::hook('view.navbar.items',[$this,'pollNav']);
        Plugin::hook('view.admin.sidebar.items',[$this,'pollAdminNav']);
        Plugin::hook('app.routes.register',[$this,'registerRoutes']);
    }
    public function configureEditor(array &$config, string $editorId){
        $config['settings']['toolbar'][] = '|';
        $config['settings']['toolbar'][] = [
            'name'=>'add-poll',
            'className'=>'fas fa-poll'
        ];
    }

    
    private function getTranslations(): array{
        return PluginHelper::getTranslations('polls');
    }
    # Add stylesheet to the tab
    public function loadStyles(&$styles){
        if(!Plugin::isActive('polls')) return;
        $styles[] = PluginAssetHelper::loadCss('polls','assets/css/polls.css');
    }
    public function loadScripts(&$scripts){
        if(!Plugin::isActive('polls')) return;
        $translations = $this->getTranslations();
        $config = Plugin::get('polls')['data']['plugin'];
        $maxOptions = $config['max_votes']??5;
        $allowMultiple = $config['allow_multiVotes']??false ? 'true' : 'false';
        $showRatio = $config['show_ratio']??false ? 'true' : 'false';
        $showRatioBar = $config['show_ratio_bar']??false ? 'true' : 'false';
        $showTotalVotes = $config['show_total_votes']??true ? 'true' : 'false';
        $disableGuestVoting = $config['disable_guest_voting']??true ? 'true' : 'false';
        $ratioBarSelectedColors = $config['ratio_bar_selected_colors']??'#4caf50';
        $ratioBarOthersColors = $config['ratio_bar_others_colors']??'#f1f1f1';
        $showPercentage = $config['show_percentage'] ? 'true' : 'false';
        $showTotalVotes = $config['show_total_votes']??true ? 'true' : 'false';
        $allowChangeVotes = $config['allow_change_vote']??false ? 'true' : 'false';
        $scripts[] = "<script>
        const baseURL = '/".UrlHelper::getBaseUrl()."';
        const poll_config = { 
            maxVotes: $maxOptions,
            allowMultipleVotes: $allowMultiple,
            showPercentage: $showPercentage,
            showRatio: $showRatio,
            showRatioBar: $showRatioBar,
            showTotalVotes: $showTotalVotes,
            disableGuestVoting: $disableGuestVoting,
            ratioBarSelectedColors: '$ratioBarSelectedColors',
            ratioBarOthersColors: '$ratioBarOthersColors',
            isLoggedIn: ".(Session::get('username') ? 'true' : 'false').",
            showTotalVotes: $showTotalVotes,
            allowChangeVotes: $allowChangeVotes
        };</script>";
        $placeholder = $translations['poll_option_placeholder']??'Add Option';
        $pollClearedInfo = $translations['poll_cleared_info']??'Your poll selections have been cleared';
        $pollVote=$translations['poll_vote']??'Vote';
        $pollClear = $translations['poll_clear']??'Clear';
        $pollClosed = $translations['poll_closed'] ?? 'This poll is closed.';
        $isLoggedIn = $translations['is_logged_in'] ?? 'You must be logged in to vote.';
        $showTotalVotes = $translations['poll_total_votes'] ?? 'Total Votes';
        $voteError = $translations['poll_vote_error'] ?? 'An error occurred while submitting your vote. Please try again.';
        $voteChange = $translations['already_voted']??'You have already voted!';
        $scripts[] = "<script>const poll_option_placeholder = '{$placeholder}';
        const poll_cleared_info = '{$pollClearedInfo}';
        const poll_vote = '{$pollVote}';
        const poll_clear = '{$pollClear}';
        const poll_closed = '{$pollClosed}';
        const is_logged_in = '{$isLoggedIn}';
        const poll_total_votes = '{$showTotalVotes}';
        const poll_vote_error = '{$voteError}';
        const allow_change_vote = '{$voteChange}'</script>";
        $scripts[] = PluginAssetHelper::loadJs('polls','assets/js/polls.js');
    }
    public function pollNav(array &$items){
        $translations = $this->getTranslations();
        $session = Session::all();
        if(isset($session['username'])){
            $items[] = "<li class='nav-item'>
                <a class='nav-link' href='/".UrlHelper::getBaseUrl()."/polls'><i class='fas fa-poll me-1'></i> {$translations['name']}</a>
            </li>";
        }
    }
    public function pollAdminNav(array &$items){
        $translations = $this->getTranslations();
        if(Session::get('username')){
            $items[] = "<li class='admin-nav-item'>
                <a class='admin-nav-link' href='/".UrlHelper::getBaseUrl()."/polls'><i class='fas fa-poll'></i> <span>{$translations['name']}</span></a>
            </li>";
        }
    }
    public function loadPollUI(){
        if(Session::get('username'))
            include_once dirname(__FILE__).DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.'frontend'.DIRECTORY_SEPARATOR.'dashboard.php';
        else 
            echo "<script>window.open('/".UrlHelper::getBaseUrl()."/login', '_self')</script>";
    }
    public function registerRoutes($router){
        $router->get('/polls',function(){
            Plugin::hook('view.main.before',[$this,'loadPollUI']);
            $GLOBALS['translations'] = $this->getTranslations();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            $config = \App\Core\Config::getInstance();
            global $translations;
            $title = $translations['name'].' - '.$config->get('site_name', \App\Helpers\Translator::trans('site.name'));
            include_once BASE_PATH.'/app/Views/layouts/frontend/main.php';        
        });
        $router->post('/polls/update', function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/updatePoll.php';
            $content = ob_get_clean(); // Captures and clears buffer

            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });
        $router->get('/polls/receiveData',function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/loadPollData.php';
            $content = ob_get_clean(); // Captures and clears buffer
            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });

        $router->post('/polls/clear', function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/clearPollVotes.php';
            $content = ob_get_clean(); // Captures and clears buffer
            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });

        $router->post('/polls/vote', function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/votePoll.php';
            $content = ob_get_clean(); // Captures and clears buffer
            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });
        $router->post('/polls/clear',function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/clearPollVotes.php';
            $content = ob_get_clean(); // Captures and clears buffer
            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });
        $router->post('/polls/vote',function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/votePoll.php';
            $content = ob_get_clean(); // Captures and clears buffer
            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });
        $router->post('/polls/check',function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/checkPoll.php';
            $content = ob_get_clean(); // Captures and clears buffer
            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });
        $router->post('/polls/results',function(){
            ob_start();
            if (!class_exists('\App\Core\Config')) 
                require_once BASE_PATH . '/app/Core/Autoloader.php';
            include_once dirname(__FILE__).'/views/backend/pollResults.php';
            $content = ob_get_clean(); // Captures and clears buffer
            header("Content-Type: application/json; charset=utf-8");
            echo $content;
        });
    }
}