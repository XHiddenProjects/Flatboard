// ============================================================================
// Security Helper: HTML Escaping to prevent XSS
// ============================================================================
function escapeHtml(text) {
    if (typeof text !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

if(typeof markdownEditors!=='undefined'){
    const btn = document.querySelector('.editor-toolbar button.add-poll'),
    previewBtn = document.querySelector('.editor-toolbar button.preview');
    if(markdownEditors?.content){
        btn.addEventListener('click',()=>{
            const cm = markdownEditors?.content.codemirror||'';
                if(cm){
                const tpl = `\`[poll]Enter_poll_ID[/poll]\``;
                if(!cm.getValue().match(/\`\[poll\](.*?)\[\/poll\]\`/)){
                    cm.replaceSelection(tpl);
                    cm.focus();
                }else cm.focus();
            }
        });

        previewBtn.addEventListener('click',()=>{
            setTimeout(()=>{
                if(markdownEditors.content.isPreviewActive()){
                    console.log('Preview');
                }else{
                    console.log('No Preview');
                }
            },100);
        })
    }else{
        btn.classList.add('disabled');
        btn.disabled = true;
        btn.setAttribute('style','pointer-events:none!important;opacity:.5!important;');
    };
}

const add_poll_option = document.querySelector('.poll-add-option');
const poll_list = document.querySelector('.poll_option_list');
let optionList = [];

if (add_poll_option && poll_list) {
  const poll_option_hidden = document.querySelector('#poll_options');

  // Helper: recompute and update the hidden field
  function updatePollList() {
    // Trim trailing empty values if desired (optional)
    // while (optionList.length && !optionList[optionList.length - 1]) optionList.pop();
    poll_option_hidden.value = optionList.join(',').replace(/,$/,'').trim();
  }

  // Event delegation for ALL input changes within poll_list
  poll_list.addEventListener('input', (e) => {
    if (e.target.matches('input[type="text"]')) {
      // Recompute current inputs *now*, not earlier
      const inputs = Array.from(poll_list.querySelectorAll('input[type="text"]'));
      const index = inputs.indexOf(e.target);

      if (index !== -1) {
        optionList[index] = e.target.value.trim();
        updatePollList();
      }
    }
  });

  // Handle add new option
  add_poll_option.addEventListener('click', () => {
    const inputs = Array.from(poll_list.querySelectorAll('input[type="text"]'));

    // Validate existing inputs before allowing a new one
    let canAdd = true;
    if (inputs.length > 0) {
      inputs.forEach((i) => {
        if (!i.value) {
          i.classList.remove('is-valid');
          i.classList.add('is-invalid');
          canAdd = false;
        } else {
          i.classList.remove('is-invalid');
          i.classList.add('is-valid');
        }
      });
    }

    if (!canAdd) return;

    // Create a new input row
    const addItemList = document.createElement('div');
    addItemList.className = 'input-group poll-option-item mt-1 has-validation';

    // You referenced poll_option_placeholder; ensure it exists in scope or replace with a default
    const placeholder = (typeof poll_option_placeholder !== 'undefined' && poll_option_placeholder) 
      ? poll_option_placeholder 
      : 'Enter option';

    addItemList.innerHTML = `
      <input type="text" placeholder="${placeholder}" class="form-control" id="poll_option_${inputs.length}"/>
      <button class="btn btn-outline-danger poll-delete-index" type="button" aria-label="Delete option">
        <i class="fa fa-trash-can"></i>
      </button>
    `;

    poll_list.appendChild(addItemList);

    // Keep optionList aligned: push an empty slot for the new input
    optionList.push('');
    updatePollList();
  });

  // Event delegation for delete buttons
  poll_list.addEventListener('click', (e) => {
    const btn = e.target.closest('.poll-delete-index');
    if (!btn) return;

    const row = btn.closest('.poll-option-item');
    if (!row) return;

    const inputs = Array.from(poll_list.querySelectorAll('input[type="text"]'));
    const input = row.querySelector('input[type="text"]');
    const index = inputs.indexOf(input);

    if (index !== -1) {
      // Remove from array and DOM
      optionList.splice(index, 1);
      row.remove();
      updatePollList();
    }
  });
}
const title = document.querySelector('#poll_title');
if(title){
    title.addEventListener('input',function(){
        const id = document.querySelector('#poll_id');
        id.value = this.value.replace(/ /g,'-').replace(/[?\\/!@#$%^&*()+={}\[\]'"<>,.|`~:;]/g,'').toLowerCase();
    });
}

const form = document.querySelector('.pollManagerForm');
if(form){
    form.addEventListener('submit',function(e){
        document.querySelector('[name="poll_save"]').innerHTML = `<i class="fa fa-spinner fa-spin"></i>`;
        e.preventDefault();
        const formData = new FormData(this);
        if(!this.querySelector('#poll_expire').value) formData.append('can_expire',false);
        else formData.append('can_expire',true);
        fetch(this.action,{
            method: 'POST',
            body: formData
        }).then(response=>response.json())
        .then((data)=>{
            if(data.success) {
                Toast.success(data.success);
                setTimeout(()=>window.location.reload(),5000);
            }
        });
    });
}



// ---- Helper: Replace poll options from a comma-separated string ----
function populateOptionsFromCSV(csv) {
  const poll_list = document.querySelector('.poll_option_list');
  const hidden = document.querySelector('#poll_options');
  if (!poll_list || !hidden) return;

  // Parse CSV → trim and drop empties
  const values = (csv || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);

  // Ensure at least two inputs exist
  const minInputs = 2;
  const finalValues = values.length >= minInputs
    ? values
    : [...values, ...Array.from({ length: minInputs - values.length }, () => '')];

  // Clear current list
  poll_list.innerHTML = '';

  // Rebuild rows: first two rows WITHOUT delete, subsequent WITH delete
  finalValues.forEach((val, idx) => {
    const row = document.createElement('div');
    row.className = 'input-group poll-option-item mt-1 has-validation';

    // Escape quotes for value attribute
    const safeVal = String(val).replace(/"/g, '&quot;');

    // Base input
    const inputHTML = `
      <input type="text"
             placeholder="${typeof poll_option_placeholder !== 'undefined' && poll_option_placeholder ? poll_option_placeholder : 'Add Option'}"
             class="form-control"
             id="poll_option_${idx}"
             value="${safeVal}"/>
    `;

    // Add delete button only for idx >= 2
    const deleteBtnHTML = (idx >= 2)
      ? `
        <button class="btn btn-outline-danger poll-delete-index" type="button" aria-label="Delete option">
          <i class="fa fa-trash-can"></i>
        </button>
      `
      : '';

    row.innerHTML = inputHTML + deleteBtnHTML;
    poll_list.appendChild(row);
  });

  // Reset and sync in-memory list + hidden field
  optionList = finalValues.map(v => v.trim());
  hidden.value = optionList.join(',');
}

function checkUserHasVoted(pollId, options){
  return fetch(`${baseURL}/polls/check`,{
    method: 'POST',
    headers:{
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({poll_id: pollId, vote_action: 'check', poll_options: options})
  });
}

function getResults(pollId){
  return fetch(`${baseURL}/polls/results`,{
    method: 'POST',
    headers:{
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({poll_id: pollId, vote_action: 'results'})
  });
}

const editPoll = document.querySelector('#poll-list');
if(editPoll){
    editPoll.addEventListener('change',function(){
        const v = this.value,
        loadSpinner = document.querySelector('.loading-poll-spinner');
        loadSpinner.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i>`;
        if(v){
          console.log(baseURL);
            fetch(`${baseURL}/polls/receiveData?poll_id=${encodeURIComponent(v)}`)
            .then(response=>response.json())
            .then(data=>{
                const d = data.poll_data;
                const title = document.querySelector('#poll_title');
                title.value = d.poll_title;
                title.classList.add('disabled');
                title.setAttribute('readonly',true);
                document.querySelector('#poll_desc').value = d.poll_description;
                document.querySelector('#poll_id').value = d.poll_id;
                document.querySelector('#poll_expire').value = d.poll_can_expire ? d.poll_expire : '';
                document.querySelector('#poll_options').value = d.poll_options;
                populateOptionsFromCSV(d.poll_options);

                document.querySelectorAll('#poll_status option').forEach(i=>{
                    i.removeAttribute('selected');
                    if(i.value===d.poll_status) i.setAttribute('selected','selected');
                });
                loadSpinner.innerHTML = ``;
            });
        }else{
            loadSpinner.innerHTML = ``;
            const title = document.querySelector('#poll_title');
            title.classList.remove('disabled');
            title.removeAttribute('readonly');
            document.querySelectorAll('input').forEach(i=>i.value='');
            document.querySelectorAll('.poll-option-item').forEach((i,k)=>{
                if(k>1) i.remove();
            });
            optionList = [];
            document.querySelectorAll('#poll_status option').forEach(i=>i.removeAttribute('selected'));
        }
    });
}

// Initialize poll code
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('.post-content code').forEach(block=>{
      const codeText = block.textContent;
      const pollMatch = codeText.match(/\[poll\](.*?)\[\/poll\]/);
      if(pollMatch){
          const pollId = pollMatch[1];
          block.innerHTML = `&nbsp;<i class="fa-solid fa-spinner fa-spin"></i>`;

          // small helper to replace only the <code> block with rendered HTML
          function replaceBlockWithHTML(codeBlock, html){
            codeBlock.insertAdjacentHTML('afterend', html);
            codeBlock.remove();
          }
          
          fetch(`${baseURL}/polls/receiveData?poll_id=${encodeURIComponent(pollId)}`)
          .then(response=>response.json())
          .then(data=>{
              if(data.poll_data){
                  const d = data.poll_data,
                  can_expire = d.poll_can_expire,
                  expire_date = d.poll_expire,
                  now = new Date();
                  checkUserHasVoted(pollId, d.poll_options.split(',').map(opt=>opt.trim()).filter(Boolean))
                  .then(response=>response.json())
                  .then(r=>{
                    let pollHTML = `<div class="poll-container" id="poll-${escapeHtml(d.poll_id)}" style="--poll-user-selection: ${poll_config.ratioBarSelectedColors}; --poll-other-selection: ${poll_config.ratioBarOthersColors};">
                    <h5 class="poll-title">${escapeHtml(d.poll_title)}</h5>
                    <p class="poll-description">${escapeHtml(d.poll_description)}</p>
                    <form class="poll-form" data-poll-id="${escapeHtml(d.poll_id)}">`;
                    const expDate = new Date(expire_date||'');
                    
                    if(can_expire&&expire_date&&now>expDate||d.poll_status==='closed'){
                        pollHTML += `<div class="alert alert-info">${poll_closed}</div>`;
                        replaceBlockWithHTML(block, pollHTML);
                    }else if(!poll_config.isLoggedIn && poll_config.disableGuestVoting){
                        pollHTML += `<div class="alert alert-info">${is_logged_in}</div>`;
                        replaceBlockWithHTML(block, pollHTML);
                    }else if(!poll_config.allowChangeVotes&&r.has_voted){
                        pollHTML+=`<div class="alert alert-info">${allow_change_vote}</div>`;
                        getResults(pollId)
                        .then(response=>response.json())
                        .then(d=>{
                          d = d.results;
                          if(poll_config.showTotalVotes)
                            pollHTML += `<div class="poll-total-votes mt-2">Total Votes: <span id="total-votes-${d.poll_id}">${d.length??'0'}</span></div>`;
                            replaceBlockWithHTML(block,pollHTML);
                        });
                    }else{
                      const options = d.poll_options.split(',').map(opt=>opt.trim()).filter(Boolean);
                      options.forEach((opt,idx)=>{
                          if(poll_config&&poll_config.allowMultipleVotes){
                              pollHTML += `
                            <div class="form-check">
                              <input class="form-check-input poll-option-input" type="checkbox" name="poll_option_${d.poll_id}" id="option_${d.poll_id}_${idx}" value="${escapeHtml(opt)}">
                              <label class="form-check-label poll-option-label" for="option_${d.poll_id}_${idx}">
                                <span class="poll-option-text">${escapeHtml(opt)}</span>
                              </label>
                            </div>`;
                          }else{
                            pollHTML += `
                            <div class="form-check">
                              <input class="form-check-input poll-option-input" type="radio" name="poll_option_${d.poll_id}" id="option_${d.poll_id}_${idx}" value="${escapeHtml(opt)}">
                              <label class="form-check-label poll-option-label" for="option_${d.poll_id}_${idx}">
                                <span class="poll-option-text">${escapeHtml(opt)}
                                `;
                                if(poll_config.showPercentage) pollHTML += `<span class="poll-option-percentage float-end">0%</span>`;
                                pollHTML += `
                                </span>
                              </label>
                            </div>`;
                        }
                      });
                      pollHTML += `
                      <button type="button" class="btn btn-primary mt-2 poll-vote-button"><i class="fa-solid fa-check-to-slot"></i>&nbsp;&nbsp;${poll_vote}</button>
                      <button type="button" class="btn btn-warning mt-2 poll-vote-clear"><i class="fa-solid fa-eraser"></i>&nbsp;&nbsp;${poll_clear}</button>
                      `;
                      if(poll_config.showTotalVotes)
                          pollHTML += `<div class="poll-total-votes mt-2">Total Votes: <span id="total-votes-${d.poll_id}">0</span></div>`;
                      if(poll_config.showRatioBar){
                          pollHTML += `<div class="poll-ratio-bar mt-2" id="poll-ratio-bar-${d.poll_id}">
                            `;
                          const colors = [
                            "red",
                            "blue",
                            "green",
                            "yellow",
                            "purple",
                            "orange",
                            "teal",
                            "pink",
                            "brown",
                            "gray",
                            "cyan",
                            "lime",
                            "indigo",
                            "magenta",
                            "violet"
                          ];
                          options.forEach((opt,idx)=>{
                              pollHTML += `<div class="poll-ratio-segment" id="poll-ratio-segment-${escapeHtml(d.poll_id)}-${idx}" style="width:0%;background-color:${colors[idx]};"></div>`;
                          });
                            pollHTML += `
                        </div>`;
                      }
                      if(poll_config.showRatio)
                        pollHTML += `<div class="poll-ratio-values mt-2" id="poll-ratio-values-${d.poll_id}"></div>`;
                      pollHTML +=  `
                      </form>
                      <div class="poll-results mt-3" id="poll-results-${d.poll_id}" style="display:none;"></div>
                      </div>`;
                      replaceBlockWithHTML(block, pollHTML);
                      document.querySelector('.poll-vote-button').addEventListener('click',function(){
                          const pollForm = this.closest('.poll-form');
                          const selectedOptions = [];
                          pollForm.querySelectorAll('.poll-option-input').forEach(i=>{
                              if(i.checked) selectedOptions.push(i.value);
                          });
                          if(selectedOptions.length===0){
                              Toast.error(poll_select_option);
                              return;
                          }
                          fetch(`${baseURL}/polls/vote`,{
                              method: 'POST',
                              headers: {
                                  'Content-Type': 'application/json',
                                  'X-CSRF-TOKEN': document.head.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                              },
                              body: JSON.stringify({poll_id: d.poll_id,selected_options: selectedOptions, vote_action: 'vote'})
                          }).then(response=>response.json())
                          .then(data=>{
                              if(data.success){
                                  Toast.success(data.success);
                                  setTimeout(()=>window.location.reload(),3000);
                              }
                          }).catch(err=>{
                              Toast.error(poll_vote_error);
                          });
                      });
                      document.querySelector('.poll-vote-clear').addEventListener('click',function(){
                          const pollForm = this.closest('.poll-form');
                          // avoid unused variable warning by not declaring an unused const
                          const _id = pollForm.getAttribute('data-poll-id');
                          pollForm.querySelectorAll('.poll-option-input').forEach(i=>i.checked=false);
                          fetch(`${baseURL}/polls/clear`,{
                              method: 'POST',
                              headers: {
                                  'Content-Type': 'application/json'
                              },
                              body: JSON.stringify({poll_id: _id, vote_action: 'clear'})
                          }).then(response=>response.json())
                          .then(data=>{
                              if(data.success){
                                  Toast.success(data.success);
                                  setTimeout(()=>window.location.reload(),3000);
                              }
                          });
                      });
                    }
                });
              }
        });
      }
  });
});