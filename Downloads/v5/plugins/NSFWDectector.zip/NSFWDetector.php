<?php
/**
 * Project Name: NSFW Detector
 * Project URL: https://github.com/XHiddenProject/NSFWDectector
 * Project Author: Gavin
 * 
 * All Flatboard code is released under the GPL3 license.
 */
namespace App\Plugins\NSFWDetector;

use App\Core\Plugin;
use App\Core\PluginHelper;
use App\Helpers\PluginAssetHelper;
use App\Helpers\UrlHelper;

class NSFWDetector{
     public function boot(): void{
        # Plugin initialization
        Plugin::hook('view.header.styles', [$this, 'loadStyles']);
        Plugin::hook('view.footer.scripts', [$this, 'loadScripts']);
        if(Plugin::getData('NSFWDetector')==null){
             Plugin::saveData('NSFWDetector',[
                # Block nudity
                'switch_block_nudity'=>'1',
                # Block Drugs
                'switch_block_drugs'=>'1',
                # Block any minors (underage children)
                'switch_block_minors'=>'1',
                # Block weapons
                'switch_block_weapons'=>'1',
                # Block SA/DV images
                'switch_block_sa_dv'=>'1',
                # Block SA toys images
                'switch_block_sa_toys'=>'1',
                # Enables filtered words safety
                'switch_enable_filter_words'=>'1',
                # List of forbidden words
                'textarea_forbidden_words_list'=>[
                    "damn",
                    "hell",
                    "crap",
                    "piss",
                    "bastard",
                    "ass",
                    "bitch",
                    "shit",
                    "fuck",
                    "dick",
                    "cock",
                    "pussy",
                    "asshole",
                    "motherfucker",
                    "cunt",
                    "whore",
                    "slut",
                    "fag",
                    "faggot",
                    "retard",
                    "nigger",
                    "nigga",
                    "chink",
                    "spic",
                    "kike",
                    "wetback",
                    "gook",
                    "dyke",
                    "tranny",
                    "prick",
                    "bollocks",
                    "wanker",
                    "twat",
                    "tosser",
                    "bugger",
                    "arse",
                    "shag",
                    "bloody",
                    "git",
                    "sod",
                    "slag",
                    "minge",
                    "bellend",
                    "knob",
                    "prat",
                    "pillock",
                    "plonker",
                    "numpty",
                    "muppet",
                    "daft",
                    "dumbass",
                    "jackass",
                    "douche",
                    "douchebag",
                    "tits",
                    "boobs",
                    "titties",
                    "hooker",
                    "prostitute",
                    "pimp",
                    "rape",
                    "rapist",
                    "molest",
                    "pedophile",
                    "pedo",
                    "nazi",
                    "hitler",
                    "terrorist",
                    "jihad",
                    "suicide",
                    "kill",
                    "murder",
                    "死ね", // Japanese slur
                    "puta", // Spanish
                    "mierda", // Spanish
                    "pendejo", // Spanish
                    "cabrón", // Spanish
                    "coño", // Spanish
                    "joder", // Spanish
                    "porra", // Portuguese
                    "merda", // Portuguese
                    "caralho", // Portuguese
                    "puto", // Spanish/Portuguese
                    "scheisse", // German
                    "arschloch", // German
                    "fotze", // German
                    "schlampe", // German
                    "merde", // French
                    "putain", // French
                    "connard", // French
                    "salope", // French
                    "bordel", // French
                    "coglione", // Italian
                    "stronzo", // Italian
                    "cazzo", // Italian
                    "puttana", // Italian
                    "vaffanculo", // Italian
                    "blyat", // Russian
                    "suka", // Russian
                    "debil" // Russian
                ],
                # Replaces bad word with character
                'forbidden_word_replace'=>'*'
            ]);
        }
    }
    
    # Load stylesheet into the forum
    public function loadStyles(&$styles): void{
        if (!$this->isPluginActive()) return;
        $styles[] = PluginAssetHelper::loadCss('NSFWDetector', 'assets/css/index.css');
    }
    # Loads scripts into the page
    public function loadScripts(&$scripts): void{
        if (!$this->isPluginActive()) return;
        try{
            $entries = [];
            $settings = Plugin::get('NSFWDetector')['data'];
            $scripts[] = "<script>";
            # Nudity
            if((int)$settings['plugin']['switch_block_nudity']){
                $nudityImg = dirname(__FILE__)."/assets/datasets/nudity";
                $files = array_values(array_diff(scandir($nudityImg), ['.','..']));
                foreach ($files as $dataset) {
                    $url = UrlHelper::plugin('NSFWDetector', "assets/datasets/nudity/$dataset");
                    array_push($entries, "'" . addslashes($url) . "'");
                }
            }
            # Drugs
            if((int)$settings['plugin']['switch_block_drugs']){
                $drugImg = dirname(__FILE__)."/assets/datasets/drugs";
                $files = array_values(array_diff(scandir($drugImg), ['.','..']));
                foreach ($files as $dataset) {
                    $url = UrlHelper::plugin('NSFWDetector', "assets/datasets/drugs/$dataset");
                    array_push($entries, "'" . addslashes($url) . "'");
                }
            }
            # Minors (Underage Children)
            if((int)$settings['plugin']['switch_block_minors']){
                $minors = dirname(__FILE__)."/assets/datasets/minors";
                $files = array_values(array_diff(scandir($minors), ['.','..']));
                foreach ($files as $dataset) {
                    $url = UrlHelper::plugin('NSFWDetector', "assets/datasets/minors/$dataset");
                    array_push($entries, "'" . addslashes($url) . "'");
                }
            }
            # Weapons
            if((int)$settings['plugin']['switch_block_weapons']){
                $weapons = dirname(__FILE__)."/assets/datasets/weapons";
                $files = array_values(array_diff(scandir($weapons), ['.','..']));
                foreach ($files as $dataset) {
                    $url = UrlHelper::plugin('NSFWDetector', "assets/datasets/weapons/$dataset");
                    array_push($entries, "'" . addslashes($url) . "'");
                }
            }
            # SA or DV
            if((int)$settings['plugin']['switch_block_sa_dv']){
                $minors = dirname(__FILE__)."/assets/datasets/sexual_assult_demostic_violence";
                $files = array_values(array_diff(scandir($minors), ['.','..']));
                foreach ($files as $dataset) {
                    $url = UrlHelper::plugin('NSFWDetector', "assets/datasets/sexual_assult_demostic_violence/$dataset");
                    array_push($entries, "'" . addslashes($url) . "'");
                }
            }
            # SA and toys
            if((int)$settings['plugin']['switch_block_sa_toys']){
                $minors = dirname(__FILE__)."/assets/datasets/sexual_acts_and_toys";
                $files = array_values(array_diff(scandir($minors), ['.','..']));
                foreach ($files as $dataset) {
                    $url = UrlHelper::plugin('NSFWDetector', "assets/datasets/sexual_acts_and_toys/$dataset");
                    array_push($entries, "'" . addslashes($url) . "'");
                }
            }
            $scripts[] = "const nsfwdatasets = [".trim(implode(',',$entries))."];";
            if($settings['plugin']['switch_enable_filter_words']){
                $words = array_map(fn($e): string=>"'$e'",$settings['plugin']['textarea_forbidden_words_list']);
                $scripts[] = "const nsfwbannedWords = [".trim(implode(',',$words))."]";
                $scripts[] = "const nsfwbannedWordsReplace = '{$settings['plugin']['text_forbidden_word_replace']}'";
            }
            $scripts[]="</script>";
            $scripts[] = "<script type='module' src='".UrlHelper::plugin('NSFWDetector','assets/js/index.js')."'></script>";
        }catch(\Exception $e){
            \App\Core\Logger::error('Something went wrong for NSFWDetector', [
                'error' => $e->getMessage()
            ]);
        }
    }
    private function isPluginActive(): bool{
        $pluginData = Plugin::get('NSFWDetector');
        if (!$pluginData) return false;
        $active = $pluginData['data']['active'];
        if($active=='1'||$active===1||$active===true) return true;
        $config = \App\Core\Config::getInstance();
        $enabledPlugins = $config->get('plugins.enabled',[]);
        return \in_array('NSFWDetector',$enabledPlugins);
    }
}