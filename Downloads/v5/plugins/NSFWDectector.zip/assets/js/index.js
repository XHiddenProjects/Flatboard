import { CNN } from './mljs/classes/artificial_intelligence.class.js';

document.addEventListener('DOMContentLoaded', () => {
    nsfwbannedWords.forEach(w=>{
        document.querySelectorAll('.post-content .message p').forEach(c=>{
            if(c.innerText.match(new RegExp(`${w}`,'ig'))){
                c.innerHTML = c.innerHTML.replace(new RegExp(`${w}`,'ig'),`<span class='nsfw-bad-word'>${nsfwbannedWordsReplace.substring(0,1).repeat(w.length)}</span>`);
            }
        });
    });
    
    const promises = [];
    document.querySelectorAll('img,video').forEach((data) => {
        const src = data.src || '';
        const cnn = new CNN({ grayscale: false });
        let matched = false; // flag to control the inner loop

        for (const dataset of nsfwdatasets) {
            const p = cnn.compare(src, dataset).then((result) => {
                if (matched) return; // if already matched, skip further processing
                if (result.similarity * 100 >= 50) {
                    data.remove()
                    matched = true; // set flag to true to prevent further matches
                }
            });
            promises.push(p);
            if (matched) break; // exit the for...of loop if matched
        }
    });

    Promise.all(promises).then(() => {
        document.querySelectorAll('img,video').forEach(el => el.style.filter = 'blur(0px)');
    });

});