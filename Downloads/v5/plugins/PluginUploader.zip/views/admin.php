<?php
// Vérifier si le plugin est activé
$pluginId = 'plugin-uploader';
$isPluginActive = \App\Core\Plugin::isActive($pluginId);

if (!$isPluginActive) {
    echo '<div class="alert alert-warning">';
    echo '<h4><i class="fas fa-exclamation-triangle me-2"></i>' . \App\Helpers\Translator::trans('plugins.message.plugin_disabled', [], 'admin') . '</h4>';
    echo '<p>' . \App\Helpers\Translator::trans('plugins.message.activate_plugin_first', [], 'admin') . '</p>';
    echo '<a href="' . \App\Helpers\UrlHelper::to('admin/plugins') . '" class="btn btn-primary">';
    echo '<i class="fas fa-plug me-2"></i>' . \App\Helpers\Translator::trans('panel.menu.plugins', [], 'admin') ?: 'Plugins';
    echo '</a>';
    echo '</div>';
    return;
}

$translations = $translations ?? [];
?>
<h1><?php echo $translations['name']??'Plugin Uploader';?></h1>
    <div class="alert alert-danger d-none"></div>
    <div class="alert alert-success d-none"></div>
    <div class="row">
        <div class="col">
            <label for="plugin-upload"><?php echo $translations['upload_plugin_label']??'Upload plugin zip file';?></label>
            <input type="file" accept=".zip" id="plugin-upload" name="plugin-upload" multiple required class="form-control">
        </div>
    </div>
    <div class="row mt-2">
        <div class="col">
            <button class="btn btn-secondary w-100" type="button" name="uploadPluginSubmit"><?php echo $translations['upload_plugin_upload']??'Upload Plugin';?></button>
        </div>
    </div>

<script>
    document.querySelector('[name="uploadPluginSubmit"]').addEventListener('click',function(e) {
        <?php $jsCsrfToken = \App\Core\Csrf::token()?>;
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || 
                         document.querySelector('input[name="csrf_token"]')?.value || 
                         '<?= $jsCsrfToken ?>';
        const formData = new FormData();
        formData.append('csrfToken',csrfToken);
        // Append each file individually
        const fileInput = document.querySelector('[name="plugin-upload"]');
        for (let i = 0; i < fileInput.files.length; i++) 
            formData.append('pluginUpload[]', fileInput.files[i]);
        fetch(`<?php echo \App\Helpers\UrlHelper::to('/plugins/PluginUploader/views/frontend/uploadPlugin.php') ?>`,{
            method:'POST',
            headers:{
                'X-CSRF-Token': csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        }).then(response=>response.json())
        .then(data=>{
            const err = document.querySelector('.alert-danger'),
            success = document.querySelector('.alert-success');
            if(data['error']){
                success.classList.add('d-none');
                err.innerText = data['error'];
                err.classList.remove('d-none');
            }else{
                err.classList.add('d-none');
                success.innerText = data['success'];
                success.classList.remove('d-none');
            }
        });
    })
</script>